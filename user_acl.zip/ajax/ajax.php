<?php

ini_set('max_execution_time', 300); //300 seconds = 5 minutes 

// use bin\{WbAdaptor};
use bin\{WbAdaptor,SecureTokens};
use addon\user_acl\{AclBe, AclIntegrity};

$aJsonRespond = [];

$sAddonFile   = str_replace('\\','/',__FILE__).'/';
$sAddonPath   = dirname(dirname($sAddonFile)).'/';
$sModulesPath = dirname($sAddonPath).'/';
$sModuleName  = basename($sModulesPath);
$sAddonName   = basename($sAddonPath);

$sPattern = "/^(.*?\/)".$sModuleName."\/.*$/";
$sAppPath = preg_replace($sPattern, "$1", $sModulesPath, 1);

// comment out if you have to load config.php
if (!defined('SYSTEM_RUN') && is_readable($sAppPath.'/config.php')) {require($sAppPath.'/config.php');}


$oReg   = WbAdaptor::getInstance();
$oDb    = $oReg->getDatabase();
$oTrans = $oReg->getTranslate();

$oTrans->enableAddon('modules\\'.$sAddonName);
$aLang = $oTrans->getLangArray();
$sAddonThemeRel  = 'themes/'.(($oReg->Theme=='DefaultTheme') ? 'default' : $oReg->Theme);
$sAddonThemePath = $sAddonPath.$sAddonThemeRel;
 
try {

	/*******************************************************************************************/
	//    SimpleCommandDispatcher
	/*******************************************************************************************/
	if (\is_readable(\dirname(__DIR__).'/SimpleCommandDispatcher.inc.php')) {
		require (\dirname(__DIR__).'/SimpleCommandDispatcher.inc.php');
	}
    $admin = new admin('Modules', 'module_view', FALSE, FALSE);

    if (!($admin->is_authenticated() && $admin->get_permission($sModuleName, 'module'))) {
		throw new Exception('You\'re not allowed to make changes to Module: ['.$sModuleName.']');
    }
	
	// Check FTAN
	if (\bin\SecureTokens::checkFTAN()) {
		exit(json_encode([
			's' => false,
			'refreshRequired' => true,
			'title' => $aLang['TEXT_RELOAD'].' '.$aLang['TEXT_PAGE'],
			'toast' => $aLang['MESSAGE_GENERIC_SECURITY_ACCESS'],
		]));
    } else {
		global $aToken;
		$aToken =  \bin\SecureTokens::getFTAN();	
		$aJsonRespond['newFtan'] = $aToken;
	}

    if (!class_exists('\Twig\Environment')) {
        exit(json_encode(['s'=>false,'message'=>'TWIG is not initialized!']));
    }
	
    // ================= HELPERS =================
	function toast($aLang, $action = '', $s = false, array $array = []){
		global $aToken;
		$defaults = [
			's'    => $s,
			'toastTitle' => $aLang['USER_ACL_THERE_IS_ERROR'],
			'toast'      => sprintf($aLang['USER_ACL_NO_PERMISSION_FOR_ACTION'], $action),
			'out'        => sprintf($aLang['USER_ACL_NO_PERMISSION_FOR_ACTION'], $action),
		];
		$r = array_merge($defaults, $array);
		if (!empty($aToken)) {
			$r['newFtan'] = $aToken;
		}
		return $r;
	}	
    function initTwig($path) {
        static $twig = null;
        if (!$twig) {
            $loader = new \Twig\Loader\FilesystemLoader($path);
            $twig = new \Twig\Environment($loader, [
                'autoescape' => false,
                'cache' => false,
                'auto_reload' => true
            ]);
        }
        return $twig;
    }

    function renderTwig($twig, $path, $tpl, $data, $override='') {
        if (!is_readable($path.'/'.$tpl)) return '';
        if ($override) {
            ob_start();
            $twig->createTemplate($override)->display($data);
            return ob_get_clean();
        }
        return $twig->render($tpl, $data);
    }

    // ================= INPUT =================

    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
		
    $myACL = new AclBe();
	$myACL->checkModuleIntegrity();
	$aclIntegrity = new AclIntegrity();
    $twig  = initTwig($sAddonThemePath);

    // ================= ROUTER =================
    switch ($action) {

        case 'start':
            $aJsonRespond['s'] 	= true;
			// ================= LANGUAGE VARIABLES FOR JS OUTPUT =================
            $aJsonRespond['out']['TT'] 	= $aLang['USER_ACL_MODULE_INFO'];
            $aJsonRespond['out']['TMC'] = $aLang['USER_ACL_COPIED_TO_CLIPBOARD'];
        break;

        // ================= ROLES =================
		case 'aclRoles':
			if (!$myACL->can('user_acl_view_roles')) {
				exit(json_encode(toast($aLang, $action)));
			}
			$q = trim($input['sQ'] ?? '');
			$aRoles = $myACL->getRolesOverview($q);
			$html = renderTwig($twig, $sAddonThemePath, 'acl_roles_list.twig', [
				'aRoles'     => $aRoles,
				'modules'   => $myACL->getInstalledModules(),
				'aLang'      => $aLang,
				'bCanManage' => $myACL->can('user_acl_manage_roles')
			]);

			$aJsonRespond['s'] 		= true;
			$aJsonRespond['out']	= $html;

			if ($q !== '') {
				$aJsonRespond['toastTitle'] = $aLang['USER_ACL_SEARCH_RESULTS'];
				$aJsonRespond['toast'] = sprintf($aLang['USER_ACL_RESULTS_FOUND'], count($aRoles));
			}
		break;
	
		case 'aclCompareRoles':
			if (!$myACL->can('user_acl_view_roles')) {
				exit(json_encode(toast($aLang, $action)));
			}
			$html = renderTwig($twig, $sAddonThemePath, 'acl_roles_compare.twig', [
				'aMatrix'     => $myACL->getPermissionsMatrix(),
				'aLang'      => $aLang,
			]);

			$aJsonRespond['s'] 		= true;
			$aJsonRespond['out']			= $html;
		break;

		case 'aclRoleEdit':
			if (!$myACL->can('user_acl_manage_roles')) {
				exit(json_encode(toast($aLang, $action)));
			}

			$id = (int)($input['iId'] ?? 0);
			$data = [
				'aLang'        => $aLang,
				'aData'        => $myACL->getRoleEditData($id),
			];
			
			$html = renderTwig(
				$twig,
				$sAddonThemePath,
				'acl_role_edit.twig',
				$data,
				$aTplDefaults['ACL_ROLE_EDIT'] ?? ''
			);

			$aJsonRespond['s'] = true;
			$aJsonRespond['out'] = $html;
		break;

		case 'aclRoleSave':
			if (!$myACL->can('user_acl_manage_roles')) {
				exit(json_encode(toast($aLang, $action)));
			}
			$aJsonRespond['a'] = $input['aData']['target'] ?? 'aclRoles';
			$i = $admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0);	
			$r = $myACL->saveRole($input['aData'] ?? [], $i);
			$aJsonRespond = array_merge(
				$aJsonRespond,
				$r,
				[
					's' => empty($r['error']),
				]
			);
		break;

		case 'aclRoleDeleteConfim':
			if (!$myACL->can('user_acl_manage_roles')) {
				exit(json_encode(toast($aLang, $action)));
			}
			$aInput = $input['aData'] ?? [];
			if ($aclIntegrity->isProtectedRole((int)$aInput['id'])) {
				exit(json_encode(toast($aLang, $action, false, [
					'a' => 'aclRoles'
				])));
			}
			$aData = $myACL->deleteRoleConfirm($aInput);
			$html = renderTwig($twig, $sAddonThemePath, 'acl_confirm_delete_toast.twig', $aData);
			$aJsonRespond['s'] = true;
			$aJsonRespond['id'] = $action . '-' . (int)$aInput['id'];
			$aJsonRespond['toastTitle'] = $aLang['USER_ACL_CONFIRM_DELETE'];
			$aJsonRespond['toast'] = $html;
		break;

		case 'aclRoleDelete':
			if (!$myACL->can('user_acl_manage_roles')) {
				exit(json_encode(toast($aLang, $action)));
			}

			$id = (int)($input['aData']['id'] ?? 0);

			if ($aclIntegrity->isProtectedRole($id)) {
				exit(json_encode(toast($aLang, $action, false, [
					'a' => 'aclRoles'
				])));
			}

			$r = $aclBe->deleteRole($id);

			$aJsonRespond['s'] = $r['success'];
			$aJsonRespond['a'] = 'aclRoles';
			$aJsonRespond['toastTitle'] = $aLang['USER_ACL_ROLES'];
			$aJsonRespond['toast'] = $r['toast'];
		break;

        // ================= PERMISSIONS =================
        case 'aclPermissions':
            if (!$myACL->can('user_acl_view_permissions')) {		
				exit(json_encode(toast($aLang, $action)));
            }
            $q = $input['sQ'] ?? '';
			$aPermissions = $myACL->getPermissionsOverview($q);
			foreach ($aPermissions as &$group) {
				foreach ($group as &$perm) {
					$perm['can_manage'] = $myACL->can('user_acl_manage_permissions');
					$perm['can_edit'] =
						$perm['can_manage']
						&& $aclIntegrity->isPermissionEditable(
							$perm['key'],
							$myACL->iUserId
						);
				}
			}
			unset($group, $perm);				
 			$html = renderTwig($twig, $sAddonThemePath, 'acl_permission_list.twig', [
				'aPermissions'  => $aPermissions,
				'aLang'      	=> $aLang,
			]);

			$aJsonRespond['s'] 		= true;
			$aJsonRespond['out']	= $html;
			if ($q !== '') {
				$aJsonRespond['toastTitle'] = $aLang['USER_ACL_SEARCH_RESULTS'];
				$aJsonRespond['toast'] = sprintf(
					$aLang['USER_ACL_RESULTS_FOUND'],
					count($aPermissions)
				);
			}
			$aJsonRespond['s'] = true;
			$aJsonRespond['out'] = $html;
			$aJsonRespond['rr'] = $aPermissions;
        break;

        case 'aclPermEdit':
            if (!$myACL->can('user_acl_manage_permissions')) {
                exit(json_encode(toast($aLang, $action)));
			}
            $id = (int)($input['iId'] ?? 0);
            $aData = ['id'=>'','name'=>'','key'=>''];
			$aData = $myACL->permissionEditData($id);
            $html = renderTwig($twig, $sAddonThemePath, 'acl_permission_edit.twig', [
                'aPermissions'=>$aData,
                'aLang'=>$aLang
            ]);
			$aJsonRespond['s'] = true;
			$aJsonRespond['out'] = $html;			
        break;

		case 'aclPermissionSave':
			if (!$myACL->can('user_acl_manage_permissions')) {
				exit(json_encode(toast($aLang, $action)));
			}
			// isPermissionEditable is inside savePermission method
			$aJsonRespond = $myACL->savePermission(
				$input['aData']['form'] ?? []
			);
			$aJsonRespond['a'] = 'aclPermissions';
		break;

		case 'aclPermissionDeleteConfim':
			if (!$myACL->can('user_acl_manage_permissions')) {
				exit(json_encode(toast($aLang, $action)));
			}
			$id = (int)($input['aData']['id'] ?? 0);
			$aData = $myACL->permissionEditData($id);
			if (!$aclIntegrity->isPermissionEditable($aData['key'], $myACL->iUserId)) {
				exit(json_encode(toast($aLang, $action, false, [
					'a' => 'aclPermissions'
				])));
			}
			$data = $myACL->deletePermissionConfirm([
				'id'     => $id,
				'target' => 'aclPermissions',
				'action' => $action
			]);

			if (!$data) {
				exit(json_encode([
					's'    => false,
					'toastTitle' => $aLang['USER_ACL_THERE_IS_ERROR'],
					'toast'      => $aLang['USER_ACL_NO_PERMISSIONS_FOUND']
				]));
			}

			$html = renderTwig(
				$twig,
				$sAddonThemePath,
				'acl_confirm_delete_toast.twig',
				$data,
				$aTplDefaults['ACL_PERMISSION_DELETE_CONFIRM_TOAST'] ?? ''
			);
			$aJsonRespond['h'] 			= $aLang['USER_ACL_TOAST_WAITTING_TOAST_ACTION'];
			
			$aJsonRespond['s']    = true;
			$aJsonRespond['id']         = $action.'-'.$data['TOAST_ID'];
			$aJsonRespond['toastTitle'] = $aLang['USER_ACL_CONFIRM_DELETE'];
			$aJsonRespond['toast']      = $html;

		break;

		case 'aclPermissionDelete':
			if (!$myACL->can('user_acl_manage_permissions')) {
				exit(json_encode(toast($aLang, $action)));
			}

			$id = (int)($input['aData']['id'] ?? 0);
			$aData = $myACL->permissionEditData($id);
			if (!$aclIntegrity->isPermissionEditable($aData['key'], $myACL->iUserId)) {
				exit(json_encode(toast($aLang, $action)));
			}
			$result = $myACL->deletePermission($id);

			$aJsonRespond = array_merge($aJsonRespond, $result);
			$aJsonRespond['toastTitle'] = $aLang['USER_ACL_DELETED'];
		break;
		
        // ================= USERS =================
		case 'aclUsers':
			if (!$myACL->can('user_acl_manage_users')) {
				exit(json_encode(toast($aLang, $action)));
			}

			$q = trim($input['sQ'] ?? '');
			$users = $myACL->getUsersWithRolesAndPerms($q);
			if ($q !== '') {
				$aJsonRespond['toastTitle'] = $aLang['USER_ACL_SEARCH_RESULTS'];
				$aJsonRespond['toast'] = sprintf(
					$aLang['USER_ACL_RESULTS_FOUND'],
					count($users)
				);
			}

			$html = renderTwig($twig, $sAddonThemePath, 'acl_users_list.twig', [
				'aUsers'     => $users,
				'aLang'      => $aLang,
				'bCanManage' => $myACL->can('user_acl_manage_users')
			]);

			$aJsonRespond['s'] 		= true;
			$aJsonRespond['out'] 			= $html;
		break;

		case 'aclUserEdit':
			if (!$myACL->can('user_acl_manage_users')) {
				exit(json_encode(toast($aLang, $action)));
			}

			$userId = (int)($input['iId'] ?? 0);
			$data = $myACL->getUserEditData($userId);

			$html = renderTwig(
				$twig,
				$sAddonThemePath,
				'acl_user_edit.twig',
				[
					'aLang'      => $aLang,
					'ID'      	 => $userId,
					'aUser'      => $data,
					'bCanSave'   => true
				],
				$aTplDefaults['ACL_USER_EDIT'] ?? ''
			);

			$aJsonRespond['s'] = true;
			$aJsonRespond['out'] = $html;

		break;

		case 'aclUserSave':
			if (!$myACL->can('user_acl_manage_users')) {
				exit(json_encode(toast($aLang, $action)));
			}

			$aJsonRespond = $myACL->saveUserEditData(
				$input['aData'] ?? []
			);
			$aJsonRespond['a'] = 'aclUsers';
		break;

        // ================= LOG =================
        case 'aclClearLog':
            if (!$myACL->can('user_acl_access')) {
                exit(json_encode(toast($aLang, $action)));
            }
			exit(json_encode($myACL->clearLog()));
        break;

        // =============== SETTINGS ==============
		case 'aclSettingsUsers':
		
			$iMe = $admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0);
			$aclOwners = new \addon\user_acl\AclOwners();
			$isOwner = $aclOwners->isOwner($iMe);

			if (!($myACL->can('user_acl_access') && $isOwner)) {
				exit(json_encode(toast($aLang, $action)));
			}
			$q = trim($input['sQ'] ?? '');
			$aData = $aclOwners->getOwnerUsers($q);
			$html = renderTwig($twig, $sAddonThemePath, 'acl_settings_users.twig', [
				'aUsers'     => $aData,
				'aLang'      => $aLang,
			]);

			$aJsonRespond['s'] 		= true;
			$aJsonRespond['out']	= $html;
		break;	
		case 'aclSettingsUsersSave':

			$iMe = $admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0);
			$aclOwners = new \addon\user_acl\AclOwners();
			$isOwner = $aclOwners->isOwner($iMe);

			if (!($myACL->can('user_acl_access') && $isOwner)) {
				exit(json_encode(toast($aLang, $action)));
			}
			try {
				$aclOwners->saveOwners(
					'users',
					$input['aData']['form']['owner_users[]'] ?? [],
					$iMe
				);
				$aJsonRespond['s'] = true;
				$aJsonRespond['a'] = 'aclSettingsUsers';
				$aJsonRespond['toastTitle'] = $aLang['USER_ACL_SETTINGS'];
				$aJsonRespond['toast'] = 'Owners updated successfully';				
			} catch (\RuntimeException $e) {
				$key = $e->getMessage();
				$message = $aLang[$key] ?? $key;
				exit(json_encode(
					toast(
						$aLang,
						$action,
						false,
						[
							'toastTitle' => $aLang['USER_ACL_SETTINGS'],
							'toast'       => $message,
							'out'         => $message,
							'a'           => 'aclSettingsUsers'
						]
					)
				));
			}
		break;

		case 'aclSettingsGroups':
		
			$iMe = $admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0);
			$aclOwners = new \addon\user_acl\AclOwners();
			$isOwner = $aclOwners->isOwner($iMe);

			if (!($myACL->can('user_acl_access') && $isOwner)) {
				exit(json_encode(toast($aLang, $action)));
			}
			$q = trim($input['sQ'] ?? '');
			$aData = $aclOwners->getOwnerGroups($q);
			$html = renderTwig($twig, $sAddonThemePath, 'acl_settings_groups.twig', [
				'aGroups'	=> $aData,
				'aLang'		=> $aLang,
			]);

			$aJsonRespond['s'] 		= true;
			$aJsonRespond['out']	= $html;
		break;
		case 'aclSettingsGroupsSave':

			$iMe = $admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0);
			$aclOwners = new \addon\user_acl\AclOwners();
			if (!$aclOwners->isOwner($iMe)) {
				exit(json_encode(toast($aLang, $action)));
			}

			try {
				$aclOwners->saveOwners(
					'groups',
					$input['aData']['form']['owner_groups[]'] ?? [],
					$iMe
				);
				$aJsonRespond['s'] = true;
				$aJsonRespond['a'] = 'aclSettingsGroups';
				$aJsonRespond['toastTitle'] = $aLang['USER_ACL_SETTINGS'];
				$aJsonRespond['toast'] = 'Owner groups updated successfully';
			} catch (\RuntimeException $e) {
				$key = $e->getMessage();
				$message = $aLang[$key] ?? $key;
				exit(json_encode(
					toast(
						$aLang,
						$action,
						false,
						[
							'toastTitle' => $aLang['USER_ACL_SETTINGS'],
							'toast'       => $message,
							'out'         => $message,
							'a'           => 'aclSettingsGroups'
						]
					)
				));
			}
		break;
		
        default:
            throw new Exception('Invalid action');
    }

} catch (Exception $e) {
    $aJsonRespond = [
        's'=>false,
        'message'=>$e->getMessage()
    ];
}

exit(json_encode($aJsonRespond));