<?php

/**
 * @category     Addons
 * @package      admin tool: user_acl
 * @copyright    C081
 * @author       C081
 * @license      http://www.gnu.org/licenses/gpl.html GPL License
 * @version      1.0.0
 * @lastmodified $Date: 2026/01/01
 * @since        File available since 2026/01/01
 * @description  addon user_acl, manage module owners - who can uninstall module or change settings
*/

namespace addon\user_acl;

use bin\WbAdaptor;

class AclOwners
{
    protected $oDb;
    protected $oReg;

    public function __construct()
    {
        $this->oReg = WbAdaptor::getInstance();
        $this->oDb  = $this->oReg->getDatabase();
    }

    /**
     * Return current owner settings.
     */
    public function getOwners(): array
    {
        return [
            'users'  => $this->getSettingIds('owner_user_ids'),
            'groups' => $this->getSettingIds('owner_group_ids'),
        ];
    }

    /**
     * Return all users with checked flag.
     */
    public function getOwnerUsers(string $search = ''): array
    {
        $owners = $this->getSettingIds('owner_user_ids');
        $where = '';
        if ($search !== '') {
            $search = $this->oDb->escapeString($search);
            $where = sprintf(
                "WHERE (
                    user_id LIKE '%s%%'
                    OR username LIKE '%%%s%%'
                )",
                $search,
                $search
            );
        }
        $sql = sprintf(
            "SELECT user_id, username
             FROM `%susers`
             %s
             ORDER BY user_id ASC",
            $this->oDb->sTablePrefix,
            $where
        );
        $rows = [];
        if ($res = $this->oDb->query($sql)) {
            while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
                $id = (int)$row['user_id'];
                $rows[] = [
                    'id'       => $id,
                    'username' => $row['username'],
                    'checked'  => in_array($id, $owners, true),
                ];
            }
        }
        return $rows;
    }

    /**
     * Return all groups with checked flag.
     */
    public function getOwnerGroups(string $search = ''): array
    {
        $owners = $this->getSettingIds('owner_group_ids');
        $where = '';
        if ($search !== '') {
            $search = $this->oDb->escapeString($search);
            $where = sprintf(
                "WHERE (
                    group_id LIKE '%s%%'
                    OR name LIKE '%%%s%%'
                )",
                $search,
                $search
            );
        }
        $sql = sprintf(
            "SELECT group_id,name
             FROM `%sgroups`
             %s
             ORDER BY name ASC",
            $this->oDb->sTablePrefix,
            $where
        );
        $rows = [];
        if ($res = $this->oDb->query($sql)) {

            while ($row = $res->fetchRow(MYSQLI_ASSOC)) {

                $id = (int)$row['group_id'];

                $rows[] = [
                    'id'      => $id,
                    'name'    => $row['name'],
                    'checked' => in_array($id, $owners, true),
                ];
            }
        }
        return $rows;
    }

    /**
     * Save ACL owners.
     *
     * $type:
     *  users
     *  groups
     *
     * @param string $type
     * @param array $ids
     * @param int $currentUserId
     *
     * @return bool
     */
    public function saveOwners(
        string $type,
        array $ids,
        int $currentUserId
    ): bool
    {
        $type = strtolower($type);
        if (!in_array($type, ['users','groups'], true)) {

            throw new \InvalidArgumentException(
                'Invalid owner type.'
            );
        }
        $ids = array_values(
            array_unique(
                array_filter(
                    array_map('intval', $ids)
                )
            )
        );
        sort($ids);
        $current = $this->getOwners();
        if ($type === 'users') {
            $users  = $ids;
            $groups = $current['groups'];
        } else {
            $users  = $current['users'];
            $groups = $ids;
        }
        // Protect current owner
        $this->validateOwners(
            $users,
            $groups,
            $currentUserId
        );
        if ($type === 'users') {

            return $this->saveSettingIds(
                'owner_user_ids',
                $users
            );
        }
        return $this->saveSettingIds(
            'owner_group_ids',
            $groups
        );
    }

    /**
     * Check if user is ACL owner.
     */
    public function isOwner(int $userId): bool
    {
        $ownerUsers = $this->getSettingIds(
            'owner_user_ids'
        );
        if (in_array($userId, $ownerUsers, true)) {
            return true;
        }
        $ownerGroups = $this->getSettingIds(
            'owner_group_ids'
        );
        if (empty($ownerGroups)) {
            return false;
        }
        $userGroups = $this->getCurrentUserGroups(
            $userId
        );
        return !empty(
            array_intersect(
                $userGroups,
                $ownerGroups
            )
        );
    }

    /**
     * Get IDs from settings table.
     */
    protected function getSettingIds(string $key): array
    {

        $sql = sprintf(
            "SELECT setting_value
             FROM `%smod_user_acl_settings`
             WHERE setting_key='%s'",
            $this->oDb->sTablePrefix,
            $this->oDb->escapeString($key)
        );
        $value = $this->oDb->get_one($sql);
        if (!$value) {
            return [];
        }
        return array_values(
            array_unique(
                array_filter(
                    array_map(
                        'intval',
                        explode(',', $value)
                    )
                )
            )
        );
    }

    /**
     * Save IDs to settings.
     */
    protected function saveSettingIds(
        string $key,
        array $ids
    ): bool
    {
        $value = implode(',', $ids);
        $sql = sprintf(
            "UPDATE `%smod_user_acl_settings`
             SET setting_value='%s'
             WHERE setting_key='%s'",
            $this->oDb->sTablePrefix,
            $this->oDb->escapeString($value),
            $this->oDb->escapeString($key)
        );
        return (bool)$this->oDb->query($sql);
    }



    /**
     * Prevent removing current owner.
     */
	protected function validateOwners(
		array $ownerUsers,
		array $ownerGroups,
		int $currentUserId
	): void
	{
		$owners = $this->getOwners();
		// if is direct owner
		if (in_array($currentUserId, $owners['users'], true)) {
			if (!in_array($currentUserId, $ownerUsers, true)) {
				throw new \RuntimeException(
					'USER_ACL_OWNER_REMOVE_SELF'
				);
			}
		}
		// if owner via group
		$userGroups = $this->getCurrentUserGroups($currentUserId);
		if (!empty(array_intersect(
			$userGroups,
			$owners['groups']
		))) {
			if (empty(array_intersect(
				$userGroups,
				$ownerGroups
			))) {

				throw new \RuntimeException(
					'USER_ACL_OWNER_REMOVE_GROUP'
				);
			}
		}
	}

    /**
     * Get user groups.
     */
    protected function getCurrentUserGroups(
        int $userId
    ): array
    {
        $sql = sprintf(
            "SELECT groups_id
             FROM `%susers`
             WHERE user_id=%d",
            $this->oDb->sTablePrefix,
            $userId
        );
        $value = $this->oDb->get_one($sql);
        if (!$value) {
            return [];
        }
        return array_values(
            array_unique(
                array_filter(
                    array_map(
                        'intval',
                        explode(',', $value)
                    )
                )
            )
        );
    }

}