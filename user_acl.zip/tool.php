<?php


use bin\{WbAdaptor,SecureTokens,Sanitize};
use bin\helpers\{PreCheck,msgQueue};
use src\Security\{CsfrTokens,Randomizer};
use src\Interfaces\Requester;
use vendor\phplib\Template;

use Twig\Loader\FilesystemLoader;
use Twig\Environment;
use Twig\TwigFilter;

use addon\user_acl\{AclBe};
    function executeTool($admin)
    {
/* -------------------------------------------------------- */
    $sAddonPath   = str_replace('\\','/',__DIR__).'/';
    $sModulesPath = \dirname($sAddonPath).'/';
    $sModuleName  = basename($sModulesPath);
    $sAddonName   = basename($sAddonPath);
    $ModuleRel    = ''.$sModuleName.'/';
    $sAddonRel    = ''.$sModuleName.'/'.$sAddonName.'/';
    $sPattern     = "/^(.*?\/)".$sModuleName."\/.*$/";
    $sAppPath     = preg_replace ($sPattern, "$1", $sModulesPath, 1 );
    $admin = new admin('modules', 'module_view', FALSE, FALSE);
/* -------------------------------------------------------- */
    $bLocalDebug  = (is_readable($sAddonPath.'.setDebug'));
    $bSecureToken = (!is_readable($sAddonPath.'.setToken'));

/*******************************************************************************************/
//    SimpleCommandDispatcher
/*******************************************************************************************/
    $bExcecuteCommand = false;
    if (\is_readable($sModulesPath.'SimpleCommandDispatcher.inc.php')) {
        require ($sModulesPath.'SimpleCommandDispatcher.inc.php');
    }
    $sDomain = $oReg->App->getDirNamespace(__DIR__);

// Include the PclZip constant file (thanks to
        if (!\defined('PCLZIP_ERR_NO_ERROR')) { require($sAppPath.'/include/pclzip/Constants.php'); }

        $database    = $oDb;
//        if (!\function_exists('getUniqueName')) { require($sAddonPath.'droplets.functions.php'); }
        $ToolRel     = '/admintools/tool.php?tool='.$sAddonName;
        $ToolQuery   = '?tool='.$sAddonName;
        $js_back     = $oReg->AcpUrl.'admintools/tool.php';
        $sActrionUrl = $oReg->AcpUrl.'admintools/tool.php';
        $ToolUrl     = $sActrionUrl.'?tool='.$sAddonName;
        $ApptoolLink = $oReg->AcpUrl.'admintools/index.php';

        // create default placeholder array for templates htt or Twig use
        $oTrans->enableAddon('modules\\'.$sAddonName);
        $aLang = $oTrans->getLangArray();
        $aTplDefaults = [
              'ADMIN_DIRECTORY' => \ADMIN_DIRECTORY,
              'ToolUrl' => $ToolUrl,
              'ToolRel' => $ToolQuery,
              'ToolQuery' => $ToolQuery,
              'ActionUrl' => $sActrionUrl,
              'sAddonUrl' => $sAddonUrl,
              'MODULE_NAME' => $sAddonName,
              'ApptoolLink' => $ApptoolLink,
              'sAddonThemeUrl'  => $sAddonThemeUrl,
              'AcpUrl' =>  $oReg->AcpUrl,
              'AppUrl' =>  $oReg->AppUrl,
              ];

        $sOut = '';
        msgQueue::clear();
        if (!$admin->get_permission($sAddonName,'module' ) ) {
            $admin->print_error($oTrans->MESSAGE_ADMIN_INSUFFICIENT_PRIVELLIGES, $js_back);
            exit();
        }
		
		if (class_exists('\Twig\Environment'))
		{
			// create twig template object
			$loader = new \Twig\Loader\FilesystemLoader($sAddonThemePath);
			$oTwig   = new \Twig\Environment($loader, [
				'autoescape'       => false,
				'cache'            => false,
				'strict_variables' => false,
				'debug'            => false, 
				'auto_reload'      => true,
			]);
		} else {
			echo 'Twig Error';
			exit();
		}		
		
        // prepare to get parameters (query)) from this URL string e.g. modify_droplet?droplet_id
        $aQuery = ['action'=>'overview'];
        $sql = '';
//        $aRequestVars = $_REQUEST;
        $aParseUrl  = (isset($aRequestVars['action']) ? \parse_url ($aRequestVars['action']): $aQuery );
        // sanitize command from compatibility file
        $action = \preg_replace(
            '/[^a-z\/0-1_]/siu',
            '',
            (isset($aParseUrl['path']) ? $aParseUrl['path'] : 'overview')
        );
        $sCommand = $sAddonPath.'cmd/'.$action.'.php';
        $subCommand = (isset($aRequestVars['action']) ? $aRequestVars['subCommand'] : $action);

        if (isset( $aParseUrl['query'])) {
            \parse_str($aParseUrl['query'], $aQuery);
        }
        \ob_start();
        \extract($aQuery, EXTR_PREFIX_SAME, "acl");

		$myACL = new AclBe();
		$myACL->checkModuleIntegrity();
	
		$sMain = '';

		//Include menu
		$sMenu = $sAddonPath.'cmd/menu.php';
		if (\is_readable($sMenu)) { require ( $sMenu ); }


        switch ($action):
            case 'log':
                if (\is_readable($sCommand)) { require ( $sCommand ); }
                break;
            case 'settings':
                if (\is_readable($sCommand)) { require ( $sCommand ); }
                break;				
            default:
                $sCommand = $sAddonPath.'cmd/'.'overview.php';
                if (\is_readable($sCommand)) { require ( $sCommand ); }
                break;
        endswitch;
		
		// Load css / js files from theme files
		$sPath = $sAddonThemePath.'/*{css,js}/*.{css,js}';
		$aFiles = glob($sPath, GLOB_BRACE);
		$aThemeScripts = [];
		foreach ($aFiles as $sFilePath) {
			if (\is_readable($sFilePath)) {
				$aThemeScripts[] = str_replace($oReg->AppPath, $oReg->AppUrl, $sFilePath);		
			}
		}

		$canView 				= $myACL->can('user_acl_access');
		$canViewPermissions 	= $myACL->can('user_acl_view_permissions');
		$canViewRoles 			= $myACL->can('user_acl_view_roles');
		$canViewUsers 			= $myACL->can('user_acl_manage_users');

		$activeTab = '';

		if ($canViewRoles) {
			$activeTab = 'roles';
		} elseif ($canViewPermissions) {
			$activeTab = 'permissions';
		} elseif ($canViewUsers) {
			$activeTab = 'users';
		}
	
		$sMenu = '';		
		$aMenu = [
			'HEADING'	=> $aLang['USER_ACL_MODULE_TITLE'],
			'SUBTITLE'	=> $aLang['USER_ACL_MODULE_SUBTITLE'],
			'aItems'	=> $aNavigation,
			'aLang'  	=> $aLang,
			'sAction'  	=> $action,	
			'canView'       		=> $canView,
			'canViewPermissions' 	=> $canViewPermissions,
			'canViewRoles' 			=> $canViewRoles,
			'canViewUsers' 			=> $canViewUsers,
			'activeTab'            	=> $activeTab,
		];
	
		if (is_readable($sAddonThemePath.'/menu.twig'))
		{	
			if (array_key_exists('TPL_MENU', $aTplDefaults) AND $aTplDefaults['TPL_MENU'] != ''){
				ob_start();
				$oTpl = $oTwig->createTemplate($aTplDefaults['TPL_MENU']);
				$sMenu = $oTpl->display($aMenu);
				$sMenu = \ob_get_clean();
			} else {
				$sMenu = $oTwig->render('menu.twig', $aMenu);              
			}
		}		

		$aToolOut = [
			'THEME_SCRIPTS' 	=> json_encode($aThemeScripts),	
			'WB_URL' 			=> WB_URL,
			'MENU'       		=> $sMenu,			
			'MAIN'       		=> $sMain,
			'sFtan'           	=> json_encode(\bin\SecureTokens::getFTAN()),
		];

		$aToolOut['aLang'] 	= $aLang;

		$sOut = '';
		if (is_readable($sAddonThemePath.'/overview.twig'))
		{
			if (array_key_exists('TEMPLATE_TOOL', $aTplDefaults) AND $aTplDefaults['TEMPLATE_TOOL'] != ''){
				$oTpl = $oTwig->createTemplate($aTplDefaults['TEMPLATE_TOOL']);
				$oTpl->display($aToolOut);
			} else {
				$sOut = $oTwig->render('overview.twig', $aToolOut);              
			}
		}

     // $sOut = \ob_get_clean();
        print $sOut;

        if (!empty($msg = msgQueue::getSuccess()))
        {
            echo $oApp->format_message($msg,'ok', $ToolUrl );
//            $oApp->print_success($msg, $ToolUrl);
        }
        if (!empty($msg = msgQueue::getError()))
        {
            echo $oApp->format_message($msg,'error', $ToolUrl);
//            $oApp->print_error($msg, $ToolUrl);
        }

    } // end executeTool
	
/* -------------------------------------------------------------------------------------------- */
//
/* -------------------------------------------------------------------------------------------- */
    if (!\defined('SYSTEM_RUN')) {require(\dirname(dirname((__DIR__))).'/config.php');}
    $admin = new \admin('admintools', 'admintools', false);
//    $requestMethod = \strtoupper($_SERVER['REQUEST_METHOD']);
//    $aRequestVars  = (isset(${'_'.$requestMethod})) ? ${'_'.$requestMethod} : $_REQUEST;
    executeTool($admin);
    $admin->print_footer();
    exit;
// end of file