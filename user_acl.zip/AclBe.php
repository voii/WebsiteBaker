<?php

/**
 * @category     Addons
 * @package      admin tool: user_acl
 * @copyright    C081
 * @author       C081
 * @license      http://www.gnu.org/licenses/gpl.html   GPL License
 * @version      1.0.0
 * @lastmodified $Date: 2026/01/01
 * @since        File available since 2026/01/01
 * @description  addon user_acl
*/


namespace addon\user_acl;

use bin\{WbAdaptor};

class AclBe extends Acl
{
	
    /* ================= Check Module integrity - see AclIntegrity class ===================== */
	public function checkModuleIntegrity(): void
	{
		(new AclIntegrity())->checkModuleIntegrity();
	}	
	
    /* ================= ROLES ===================== */

    /**
     * Full role overview for Roles & Permissions
     *
     * @param string $q Search by ID or role name
     * @return array
     */
    public function getRolesOverview(string $q = ''): array
    {
        $roles = [];
        $where = '';

        // SEARCH
        if ($q !== '') {
            $q = $this->oDb->escapeString($q);
            $where = "WHERE (
                        r.id LIKE '{$q}%'
                        OR r.role_name LIKE '%{$q}%'
                      )";
        }
		// ROLES + USER COUNT
        $sql = "
            SELECT
                r.id,
                r.role_name,
                r.role_description,
				r.created_by,
                COUNT(DISTINCT ur.user_id) AS users_count
            FROM {$this->oDb->sTablePrefix}mod_user_acl_roles r
            LEFT JOIN {$this->oDb->sTablePrefix}mod_user_acl_user_roles ur
                ON ur.role_id = r.id
            {$where}
            GROUP BY r.id
            ORDER BY r.role_name ASC
        ";

        if ($res = $this->oDb->query($sql)) {
            while ($row = $res->fetchRow(MYSQLI_ASSOC)) {

                $roleId = (int)$row['id'];
				$desc = ($row['role_description'] ?? '');
				$by = (($row['created_by'] == 'admin' ? '' : $this->getUsername($row['created_by'])) ?? '');
				
                $roles[$roleId] = [
                    'id'          => $roleId,
                    'name'        => $row['role_name'],
                    'slug'        => $this->makeSlug($row['role_name']),
                    'description' => $desc,
					'by' 		  => $by,
                    'usersCount'  => (int)$row['users_count'],
                    'system'      => in_array((int) $row['id'], [1], true),
                    'permissions' => [],
                    'permCount'   => 0,
                    'totalPerms'  => 0
                ];
            }
        }

        if (empty($roles)) {
            return [];
        }
        // ALL PERMISSIONS
        $allPerms = $this->getAllPerms();
        $totalPerms = count($allPerms);
        $permById = [];
        foreach ($allPerms as $perm) {
            $permById[(int)$perm['id']] = $perm;
        }
        // ROLE PERMISSIONS
        $roleIds = implode(',', array_keys($roles));
        $sql = "
            SELECT role_id, perm_id, value
            FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
            WHERE role_id IN ({$roleIds})
        ";
        $rolePerms = [];
        if ($res = $this->oDb->query($sql)) {
            while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
                $rolePerms[(int)$row['role_id']][(int)$row['perm_id']] = (int)$row['value'];
            }
        }
        // BUILD FINAL OUTPUT
        foreach ($roles as $roleId => &$role) {
            $decidedPermCount = 0;
            foreach ($permById as $permId => $perm) {
                $value = $rolePerms[$roleId][$permId] ?? 2;
                if (in_array($value, [0, 1], true)) {
                    $decidedPermCount++;
                }

                $role['permissions'][] = [
                    'id'        => $permId,
                    'key'       => $perm['key'],
                    'name'      => $perm['name'],
                    'value'     => (int)$value
                ];
            }
            usort(
                $role['permissions'],
                static fn(array $a, array $b): int => strcasecmp($a['name'], $b['name'])
            );

            $role['permCount']  = $decidedPermCount;
            $role['totalPerms'] = $totalPerms;
        }
        unset($role);
        return array_values($roles);
    }

    /**
     * Helper - Get installed modules 
     *
     * Used for grouping by prefix
	 * @return array
     */		
	public function getInstalledModules(): array
	{
		$out = [];
		$sql = "SELECT directory
				FROM {$this->oDb->sTablePrefix}addons
				WHERE type = 'module'
				AND function = 'tool'
				ORDER BY directory ASC";
		if ($res = $this->oDb->query($sql)) {
			while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
				$out[] = $row['directory'];
			}
		}
		return $out;
	}	


    /**
     * Compare Roles & Permissions screen
     *
     * @return array
     */
	public function getPermissionsMatrix(): array
	{
		// 1. Roles
		$rolesData = $this->getRolesOverview();
		if (empty($rolesData)) {
			return [];
		}
		$roles = [];
		foreach ($rolesData as $r) {
			$roles[$r['id']] = $r['name'];
		}
		// 2. Modules
		$modules = $this->getInstalledModules(); // ['user_acl','pages',...]

		// 3. Permissions
		$allPerms = $this->getAllPerms();
		$grouped = [];
		foreach ($allPerms as $perm) {
			$moduleName = 'others';
			foreach ($modules as $mod) {
				if (strpos($perm['key'], $mod . '_') === 0) {
					$moduleName = $mod;
					break;
				}
			}
			$grouped[$moduleName][$perm['id']] = [
				'id'    => (int)$perm['id'],
				'key'   => $perm['key'],
				'name'  => $perm['name'],
				'roles' => []
			];
		}
		// 4. Role permissions
		$roleIds = implode(',', array_keys($roles));
		$sql = "
			SELECT role_id, perm_id, value
			FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
			WHERE role_id IN ({$roleIds})
		";
		$rolePerms = [];
		if ($res = $this->oDb->query($sql)) {
			while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
				$rolePerms[(int)$row['role_id']][(int)$row['perm_id']] = (int)$row['value'];
			}
		}
		// 5. Build matrix
		foreach ($grouped as $module => &$perms) {
			foreach ($perms as $permId => &$perm) {
				foreach ($roles as $roleId => $roleName) {
					$value = $rolePerms[$roleId][$permId] ?? 2;
					$perm['roles'][$roleId] = [
						'role'  => $roleName,
						'value' => $value
					];
				}
			}
			// sort perms
			usort($perms, fn($a, $b) => strcasecmp($a['name'], $b['name']));
		}
		// 6. SORT MODULES (modules first, others last)
		uksort($grouped, function ($a, $b) use ($modules) {
			if ($a === 'others') return 1;
			if ($b === 'others') return -1;
			return array_search($a, $modules) <=> array_search($b, $modules);
		});
		return [
			'roles'  => $roles,
			'matrix' => $grouped
		];
	}

    /**
     * Role edit data
     *
     * @param int $roleId
     * @return array
     */
	public function getRoleEditData(int $roleId = 0): array
	{
		$role = [
			'id'          => 0,
			'name'        => '',
			'description' => ''
		];

		if ($roleId > 0) {
			$sql = "
				SELECT id, role_name, role_description
				FROM {$this->oDb->sTablePrefix}mod_user_acl_roles
				WHERE id = {$roleId}
				LIMIT 1
			";
			if ($res = $this->oDb->query($sql)) {
				if ($row = $res->fetchRow(MYSQLI_ASSOC)) {
					$role = [
						'id'          => (int)$row['id'],
						'name'        => $row['role_name'],
						'description' => $row['role_description']
					];
				}
			}
		}
		// INSTALLED MODULES
		$modules = $this->getInstalledModules();

		// ALL PERMISSIONS
		$allPerms = $this->getAllPerms();

		// ROLE PERMISSIONS
		$rolePerms = [];
		if ($roleId > 0) {
			$sql = "
				SELECT perm_id, value
				FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
				WHERE role_id = {$roleId}
			";
			if ($res = $this->oDb->query($sql)) {
				while ($row = $res->fetchRow(MYSQLI_ASSOC)) {

					$rolePerms[(int)$row['perm_id']] = (int)$row['value'];
				}
			}
		}

		// GROUP PERMISSIONS
		$grouped = [];
		foreach ($allPerms as $perm) {
			$module = 'others';
			foreach ($modules as $mod) {
				if (strpos($perm['key'], $mod . '_') === 0) {
					$module = $mod;
					break;
				}
			}
			$value = $rolePerms[$perm['id']] ?? 2;
			$grouped[$module][] = [
				'id'    => (int)$perm['id'],
				'key'   => $perm['key'],
				'name'  => $perm['name'],
				'value' => $value
			];
		}
		// SORT PERMISSIONS
		foreach ($grouped as &$perms) {
			usort(
				$perms,
				fn($a, $b) => strcasecmp($a['name'], $b['name'])
			);
		}
		unset($perms);
		// SORT MODULES
		uksort($grouped, function ($a, $b) use ($modules) {
			if ($a === 'others') return 1;
			if ($b === 'others') return -1;
			return array_search($a, $modules)
				<=> array_search($b, $modules);
		});
		return [
			'role'         => $role,
			'modules'      => $modules,
			'permsGrouped' => $grouped
		];
	}

    /**
     * Save Role data
     *
     * @param array $aData form data
     * @param int $id ID int or null
     * @return array
     */
	 
	public function saveRole(array $aData, int $iUserId = 0): array
	{
		$form = $aData['form'] ?? [];

		$roleId      = (int)($form['id'] ?? 0);
		$name        = trim($form['title'] ?? '');
		$description = trim($form['description'] ?? '');
		$createdBy   = $iUserId ?: ($_SESSION['USER_ID'] ?? 0);

		if ($name === '') {
			return [
				'success'    => false,
				'toastTitle' => $this->aLang['USER_ACL_THERE_IS_ERROR'],
				'toast'      => $this->aLang['USER_ACL_ROLE_TITLE_EMPTY']
			];
		}

		$name        = mb_substr($this->oDb->escapeString($name), 0, 191, 'UTF-8');
		$description = mb_substr($this->oDb->escapeString($description), 0, 191, 'UTF-8');

		// save role
		if ($roleId > 0) {
			$this->oDb->query("
				UPDATE {$this->oDb->sTablePrefix}mod_user_acl_roles
				SET role_name = '{$name}',
					role_description = '{$description}'
				WHERE id = {$roleId}
			");
			$toast = sprintf($this->aLang['USER_ACL_ROLE_UPDATED'], $name);
		} else {
			$this->oDb->query("
				INSERT INTO {$this->oDb->sTablePrefix}mod_user_acl_roles
				(
					role_name,
					role_description,
					created_by
				)
				VALUES
				(
					'{$name}',
					'{$description}',
					{$createdBy}
				)
			");
			$roleId = (int)$this->oDb->get_one("SELECT LAST_INSERT_ID()");
			$toast = sprintf($this->aLang['USER_ACL_ROLE_ADDED'], $name);
		}

		// admin role => auto allow all
		if ((new AclIntegrity())->isProtectedRole($roleId)) {
			$this->syncAdminPermissions();
		} else {
			foreach ($form as $k => $v) {
				if (strpos($k, 'perm_') !== 0) {
					continue;
				}
				$permId = (int)str_replace('perm_', '', $k);
				$value  = (int)$v;
				$this->saveRolePermissionValue($roleId, $permId, $value);
			}
		}
		return [
			'success'    => true,
			'a'          => $aData['target'] ?? 'aclRoles',
			'toastTitle' => $this->aLang['USER_ACL_ROLES'],
			'toast'      => $toast
		];
	}
	 
    /**
     * Delete Role confirm toast
     *
     * @param array $aData form data
     * @return array
     */
    public function deleteRoleConfirm(array $aData)
    {
		
		$id = (int)($aData['id'] ?? 0);
		
        $sName = $this->oDb->get_one("
            SELECT role_name 
            FROM {$this->oDb->sTablePrefix}mod_user_acl_roles 
            WHERE id = {$id}
        ");

        $usersCount = (int)$this->oDb->get_one("
            SELECT COUNT(*) 
            FROM {$this->oDb->sTablePrefix}mod_user_acl_user_roles 
            WHERE role_id = {$id}
        ");

		$permsCount = (int)$this->oDb->get_one("
			SELECT COUNT(*) 
			FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
			WHERE role_id = {$id}
			AND value IN (0,1)
		");

        $warning = [];
        if ($usersCount) {
            $warning[] = sprintf($this->aLang['USER_ACL_TOAST_ROLE_ASSIGNED_USERS'], $usersCount);
        }

        if ($permsCount) {
            $warning[] = sprintf($this->aLang['USER_ACL_TOAST_ROLE_HAS_PERMISSIONS'], $permsCount);
        }

        return [
            'TOAST_TEXT' 		=> $this->aLang['USER_ACL_YOU_WILL_DELETE_ROLE'].' <u>'.$sName.'</u>'.
								($warning ? ' ('.implode(', ', $warning).')' : ''),	
			'TOAST_BTN_DELETE'	=> $this->aLang['USER_ACL_DELETE'], 
			'TOAST_BTN_CANCEL'	=> $this->aLang['USER_ACL_CANCEL'], 	
			'TOAST_CONFIRM'	=> 'aclRoleDelete', 
			'TOAST_TARGET' 	=> $aData['target'], 
			'TOAST_ID' 		=> $id, 
			'TOAST_ACTION' 	=> $aData['action']
		];
    }

    /**
     * Delete Role
     *
     * @param int $id Role ID
     * @return array
     */
	public function deleteRole(int $id): array
	{
		$id = (int)$id;

		if ($id < 1) {
			return [
				'success' => false,
				'toast'   => $this->aLang['USER_ACL_NO_ROLES_FOUND']
			];
		}

		// protect admin role
		if ((new AclIntegrity())->isProtectedRole($id)) {
			return [
				'success' => false,
				'toast'   => $this->aLang['USER_ACL_TOAST_ROLE_SYSTEM_PROTECTED']
			];
		}

		$name = $this->oDb->get_one("
			SELECT role_name
			FROM {$this->oDb->sTablePrefix}mod_user_acl_roles
			WHERE id = {$id}
			LIMIT 1
		");

		if (!$name) {
			return [
				'success' => false,
				'toast'   => $this->aLang['USER_ACL_NO_ROLES_FOUND']
			];
		}

		// delete relations first
		$this->oDb->query("
			DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_user_roles
			WHERE role_id = {$id}
		");

		$this->oDb->query("
			DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
			WHERE role_id = {$id}
		");

		// delete role
		$this->oDb->query("
			DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_roles
			WHERE id = {$id}
			LIMIT 1
		");
		return [
			'success' => true,
			'toast'   => sprintf($this->aLang['USER_ACL_ROLE_DELETED'], $name)
		];
	}

    /* ================= PERMISSIONS ===================== */
    /**
     * Full Permissions overview
     *
     * @param string $q Search by ID or permission name or key
     * @return array
     */
	public function getPermissionsOverview(string $q = ''): array
	{
		$where = '';

		// SEARCH
		if ($q !== '') {
			$q = $this->oDb->escapeString($q);
			$where = "WHERE (
				id LIKE '{$q}%'
				OR perm_name LIKE '%{$q}%'
				OR perm_key LIKE '{$q}%'
			)";
		}

		$sql = "
			SELECT id, perm_name, perm_key
			FROM {$this->oDb->sTablePrefix}mod_user_acl_permissions
			{$where}
			ORDER BY perm_key ASC
		";

		$modules = $this->getInstalledModules();

		$groups = [];

		// group by modules
		foreach ($modules as $module) {
			$groups[$module] = [];
		}

		$groups['other'] = [];

		if ($res = $this->oDb->query($sql)) {

			while ($r = $res->fetchRow(MYSQLI_ASSOC)) {

				$group = 'other';

				foreach ($modules as $module) {

					if (str_starts_with($r['perm_key'], $module.'_')) {
						$group = $module;
						break;
					}
				}

				$groups[$group][] = [
					'id'   => (int)$r['id'],
					'name' => $r['perm_name'],
					'key'  => $r['perm_key'],
				];
			}
		}

		// sort
		foreach ($groups as &$permissions) {
			usort(
				$permissions,
				static fn(array $a, array $b): int => strcasecmp($a['name'], $b['name'])
			);
		}
		unset($permissions);
		return array_filter($groups);
	}


    /**
     * Permission edit data
     *
     * @param int $id
     * @return array
     */
	public function permissionEditData(int $id = 0): array
	{
		$id = (int)$id;
		$row = [
			'id'   => 0,
			'name' => '',
			'key'  => ''
		];
		if ($id > 0) {
			$sql = "
				SELECT *
				FROM {$this->oDb->sTablePrefix}mod_user_acl_permissions
				WHERE id = {$id}
				LIMIT 1
			";
			if ($res = $this->oDb->query($sql)) {
				if ($r = $res->fetchRow(MYSQLI_ASSOC)) {
					$row = [
						'id'   => (int)$r['id'],
						'name' => $r['perm_name'],
						'key'  => $r['perm_key']
					];
				}
			}
		}
		return $row;
	}
	/**
	 * Save permission (insert / update)
	 *
	 * @param array $aData Form data
	 * @return array
	 */
	public function savePermission(array $aData): array
	{
		$id   = (int)($aData['id'] ?? 0);
		$name = trim($aData['name'] ?? '');

		$keyInput = trim($aData['key'] ?? '');
		$rawKey   = ($keyInput !== '') ? $keyInput : $name;
		$key       = $this->makeSlug($rawKey);

		// Validation
		if ($name === '' || $key === '') {

			$msg = [];

			if ($name === '') {
				$msg[] = $this->aLang['USER_ACL_PERMISSION_NAME'].' '.$this->aLang['USER_ACL_IS_EMPTY'];
			}

			if ($key === '') {
				$msg[] = $this->aLang['USER_ACL_PERMISSION_KEY'].' '.$this->aLang['USER_ACL_IS_EMPTY'];
			}

			return [
				'success'    => false,
				'toastTitle' => $this->aLang['USER_ACL_PERMISSIONS'],
				'toast'      => implode(', ', $msg),
				'a'          => $aData['target'] ?? 'aclPermissions',
			];
		}

		$aclIntegrity = new AclIntegrity();

		// Existing permission
		if ($id > 0) {
			if (!$aclIntegrity->isPermissionEditable($key, $this->iUserId)) {
				return [
					'success'    => false,
					'toastTitle' => $this->aLang['USER_ACL_THERE_IS_ERROR'],
					'toast'      => sprintf(
						$this->aLang['USER_ACL_NO_PERMISSION_FOR_ACTION'],
						$this->aLang['USER_ACL_SAVE']
					),
					'a'          => $aData['target'] ?? 'aclPermissions',
				];
			}

		}
		// New permission
		else {
			if (!$aclIntegrity->isPermissionEditable($key, $this->iUserId)) {
				return [
					'success'    => false,
					'toastTitle' => $this->aLang['USER_ACL_THERE_IS_ERROR'],
					'toast'      => sprintf(
						$this->aLang['USER_ACL_NO_PERMISSION_FOR_ACTION'],
						$this->aLang['USER_ACL_ADD']
					),
					'a'          => $aData['target'] ?? 'aclPermissions',
				];
			}
		}

		// Duplicate check
		$exists = $this->oDb->get_one("
			SELECT id
			FROM {$this->oDb->sTablePrefix}mod_user_acl_permissions
			WHERE (perm_key = '{$key}' OR perm_name = '{$name}')
			  AND id != {$id}
			LIMIT 1
		");

		if ($exists) {

			return [
				'success'    => false,
				'toastTitle' => $this->aLang['USER_ACL_PERMISSIONS'],
				'toast'      => $this->aLang['USER_ACL_TOAST_ALREADY_EXISTS'],
				'a'          => $aData['target'] ?? 'aclPermissions',
			];
		}

		// Save
		if ($id > 0) {

			$this->oDb->query("
				UPDATE {$this->oDb->sTablePrefix}mod_user_acl_permissions
				SET
					perm_key  = '{$key}',
					perm_name = '{$name}'
				WHERE id = {$id}
			");

			$toast = sprintf(
				$this->aLang['USER_ACL_PERMISSION_UPDATED'],
				$name
			);

		} else {

			$this->oDb->query("
				INSERT INTO {$this->oDb->sTablePrefix}mod_user_acl_permissions
					(perm_key, perm_name)
				VALUES
					('{$key}', '{$name}')
			");

			$id = (int)$this->oDb->get_one("SELECT LAST_INSERT_ID()");

			$toast = sprintf(
				$this->aLang['USER_ACL_PERMISSION_ADDED'],
				$name
			);
		}

		// Administrator role always gets new permissions
		$this->syncAdminPermission($id);

		return [
			'success'    => true,
			'toastTitle' => $this->aLang['USER_ACL_PERMISSIONS'],
			'toast'      => $toast,
			'a'          => $aData['target'] ?? 'aclPermissions',
		];
	} 

	/**
	 * Delete Permission confirm toast
	 *
	 * @param array $aData form data
	 * @return array
	 */
	public function deletePermissionConfirm(array $aData): array
	{
		$id = (int)($aData['id'] ?? 0);

		if ($id < 1) {
			return [];
		}

		$name = $this->oDb->get_one("
			SELECT perm_name
			FROM {$this->oDb->sTablePrefix}mod_user_acl_permissions
			WHERE id = {$id}
			LIMIT 1
		");

		if (!$name) {
			return [];
		}

		$rolesCount = (int)$this->oDb->get_one("
			SELECT COUNT(*)
			FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
			WHERE perm_id = {$id}
			AND value = 1
		");

		$usersDirect = (int)$this->oDb->get_one("
			SELECT COUNT(*)
			FROM {$this->oDb->sTablePrefix}mod_user_acl_user_perms
			WHERE perm_id = {$id}
		");

		$usersViaRoles = (int)$this->oDb->get_one("
			SELECT COUNT(DISTINCT ur.user_id)
			FROM {$this->oDb->sTablePrefix}mod_user_acl_user_roles ur
			INNER JOIN {$this->oDb->sTablePrefix}mod_user_acl_role_perms rp
				ON rp.role_id = ur.role_id
			WHERE rp.perm_id = {$id}
			AND rp.value = 1
		");

		$warning = [];

		if ($rolesCount > 0) {
			$warning[] = sprintf(
				$this->aLang['USER_ACL_TOAST_PERMISSIONS_IN_ROLES'],
				$rolesCount
			);
		}

		if ($usersViaRoles > 0) {
			$warning[] = sprintf(
				$this->aLang['USER_ACL_TOAST_PERMISSIONS_VIA_ROLES'],
				$usersViaRoles
			);
		}

		if ($usersDirect > 0) {
			$warning[] = sprintf(
				$this->aLang['USER_ACL_TOAST_PERMISSIONS_OVERRIDES'],
				$usersDirect
			);
		}

		return [
			'TOAST_TEXT' => $this->aLang['USER_ACL_YOU_WILL_DELETE_PERMISSION'].' <u>'.$name.'</u>'.
							($warning ? ' ('.implode(', ', $warning).')' : ''),

			'TOAST_BTN_DELETE' => $this->aLang['USER_ACL_DELETE'],
			'TOAST_BTN_CANCEL' => $this->aLang['USER_ACL_CANCEL'],

			'TOAST_CONFIRM' => 'aclPermissionDelete',
			'TOAST_TARGET'  => $aData['target'] ?? 'aclPermissions',
			'TOAST_ID'      => $id,
			'TOAST_ACTION'  => $aData['action'] ?? ''
		];
	}

	/**
	 * Delete Permission
	 *
	 * @param int $id Permission ID
	 * @return array
	 */
	public function deletePermission(int $id): array
	{
		$id = (int)$id;

		if ($id < 1) {
			return [
				'success' => false,
				'toast'   => $this->aLang['USER_ACL_NO_PERMISSIONS_FOUND']
			];
		}

		$name = $this->oDb->get_one("
			SELECT perm_name
			FROM {$this->oDb->sTablePrefix}mod_user_acl_permissions
			WHERE id = {$id}
			LIMIT 1
		");

		if (!$name) {
			return [
				'success' => false,
				'toast'   => $this->aLang['USER_ACL_NO_PERMISSIONS_FOUND']
			];
		}

		// FK cascade delete role_perms + user_perms
		$this->oDb->query("
			DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_permissions
			WHERE id = {$id}
			LIMIT 1
		");

		return [
			'success' => true,
			'a'       => 'aclPermissions',
			'toast'   => sprintf(
				$this->aLang['USER_ACL_PERMISSION_DELETED'],
				$name
			)
		];
	}

    /* ================= USERS ===================== */
    /**
     * Full Users overview
     *
     * @param string $q Search by USER_ID or username
     * @return array
     */
	public function getUsersWithRolesAndPerms(string $q = ''): array
	{
		$userRoles = [];
		$userPerms = [];

		// =====================
		// SEARCH USERS
		// =====================
		$sqlQ = '';

		if ($q !== '') {
			$q = $this->oDb->escapeString($q);
			$sqlQ = "WHERE (user_id LIKE '{$q}%' OR username LIKE '%{$q}%')";
		}

		// =====================
		// USERS
		// =====================
		$users = [];

		$sql = "SELECT user_id, username
				FROM {$this->oDb->sTablePrefix}users
				{$sqlQ}
				ORDER BY username ASC";

		if ($res = $this->oDb->query($sql)) {
			while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
				$users[] = $row;
			}
		}

		if (!$users) {
			return [];
		}

		$userIds = array_column($users, 'user_id');
		$inUsers = implode(',', array_map('intval', $userIds));

		// =====================
		// USER ROLES
		// =====================
		$sql = "SELECT user_id, role_id
				FROM {$this->oDb->sTablePrefix}mod_user_acl_user_roles
				WHERE user_id IN ({$inUsers})";

		if ($res = $this->oDb->query($sql)) {
			while ($r = $res->fetchRow(MYSQLI_ASSOC)) {
				$userRoles[$r['user_id']][] = (int)$r['role_id'];
			}
		}

		// =====================
		// USER PERMISSIONS (ONLY OVERRIDES)
		// =====================
		$sql = "SELECT user_id, perm_id, value
				FROM {$this->oDb->sTablePrefix}mod_user_acl_user_perms
				WHERE user_id IN ({$inUsers})";

		if ($res = $this->oDb->query($sql)) {
			while ($r = $res->fetchRow(MYSQLI_ASSOC)) {
				$userPerms[$r['user_id']][] = (int)$r['value'];
			}
		}

		// =====================
		// BUILD OUTPUT
		// =====================
		$out = [];

		foreach ($users as $u) {

			$uid = (int)$u['user_id'];

			// roles (ONLY names)
			$roleNames = [];

			if (!empty($userRoles[$uid])) {
				foreach ($userRoles[$uid] as $rid) {
					$name = $this->getRoleNameFromID($rid);
					if ($name) {
						$roleNames[] = $name;
					}
				}
			}

			// =====================
			// OVERRIDE COUNTS (ONLY USER PERMS TABLE)
			// =====================
			$allowCount = 0;
			$denyCount  = 0;

			if (!empty($userPerms[$uid])) {
				foreach ($userPerms[$uid] as $val) {
					if ($val === 1) $allowCount++;
					if ($val === 0) $denyCount++;
				}
			}

			$out[] = [
				'userId'     => $uid,
				'username'   => $u['username'],
				'roles'      => $roleNames,
				'allowCount' => $allowCount,
				'denyCount'  => $denyCount,
				'hasRoles'   => !empty($roleNames),
				'hasOverrides' => ($allowCount > 0 || $denyCount > 0),
			];
		}
		return $out;
	}

    /**
     * Edit Users Roles and Permissions
     *
     * @param int ID
     * @return array
     */
	public function getUserEditData(int $userId): array
	{
		$user = [
			'id'       => $userId,
			'username' => $this->getUsername($userId) ?? ''
		];

		$modules = $this->getInstalledModules();

		/* =========================================
		   USER ROLES
		========================================= */

		$userRoleIds = [];

		$sql = "
			SELECT role_id
			FROM {$this->oDb->sTablePrefix}mod_user_acl_user_roles
			WHERE user_id = {$userId}
		";

		if ($res = $this->oDb->query($sql)) {
			while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
				$userRoleIds[] = (int)$row['role_id'];
			}
		}

		$rolesOut = [];

		foreach ($this->getAllRoles() as $role) {
			$rolesOut[] = [
				'id'          => (int)$role['id'],
				'name'        => 'role_'.$role['id'],
				'title'       => $role['name'],
				'description' => $role['description'],
				'checked'     => in_array((int)$role['id'], $userRoleIds, true)
			];
		}

		/* =========================================
		   ALL PERMISSIONS
		========================================= */

		$allPerms = array_values($this->getAllPerms());

		/* =========================================
		   USER DIRECT PERMISSIONS
		========================================= */

		$userPerms = [];

		$sql = "
			SELECT perm_id, value
			FROM {$this->oDb->sTablePrefix}mod_user_acl_user_perms
			WHERE user_id = {$userId}
		";

		if ($res = $this->oDb->query($sql)) {
			while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
				$userPerms[(int)$row['perm_id']] = (int)$row['value'];
			}
		}

		/* =========================================
		   ROLE PERMISSIONS
		========================================= */

		$rolePerms = [];
		if (!empty($userRoleIds)) {
			$roleIds = implode(',', $userRoleIds);
			$sql = "
				SELECT role_id, perm_id, value
				FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
				WHERE role_id IN ({$roleIds})
				ORDER BY value DESC
			";

			if ($res = $this->oDb->query($sql)) {
				while ($row = $res->fetchRow(MYSQLI_ASSOC)) {

					$permId = (int)$row['perm_id'];
					$roleId = (int)$row['role_id'];
					$value  = (int)$row['value'];

					if (!isset($rolePerms[$permId])) {
						$rolePerms[$permId] = [
							'value' => $value,
							'roles' => []
						];
					}

					if ($value === 1) {
						$rolePerms[$permId]['value'] = 1;
					}

					$rolePerms[$permId]['roles'][] = $this->getRoleNameFromID($roleId);
				}
			}
		}

		/* =========================================
		   BUILD
		========================================= */

		$grouped = [];

		foreach ($allPerms as $perm) {

			$permId = (int)$perm['id'];

			$module = 'others';

			foreach ($modules as $mod) {
				if (strpos($perm['key'], $mod.'_') === 0) {
					$module = $mod;
					break;
				}
			}

			$isUserOverride  = array_key_exists($permId, $userPerms);
			$hasRoleDecision = array_key_exists($permId, $rolePerms);

			$selected = 2;
			$badgeClass = 5;
			$iconClass = 3;
			$stateLabel = $this->aLang['USER_ACL_IGNORED'];
			$inheritRoles = [];
			$bold = false;

			if ($isUserOverride) {
				$bold = true;
				if ((int)$userPerms[$permId] === 1) {
					$selected = 1;
					$badgeClass = 1;
					$iconClass = 1;
					$stateLabel = $this->aLang['USER_ACL_ALLOWED'];
				} else {
					$selected = 0;
					$badgeClass = 2;
					$iconClass = 2;
					$stateLabel = $this->aLang['USER_ACL_DENIED'];
				}
			} elseif ($hasRoleDecision) {
				$inheritRoles = $rolePerms[$permId]['roles'] ?? [];
				if ((int)$rolePerms[$permId]['value'] === 1) {
					$badgeClass = 3;
					$iconClass = 1;
					$stateLabel = '['.$this->aLang['USER_ACL_ALLOWED'].'] '.$this->aLang['USER_ACL_INHERITED_VIA_ROLE'];
				} else {
					$badgeClass = 4;
					$iconClass = 2;
					$stateLabel = '['.$this->aLang['USER_ACL_DENIED'].'] '.$this->aLang['USER_ACL_INHERITED_VIA_ROLE'];
				}
			}

			$grouped[$module][] = [
				'id'           => $permId,
				'key'          => $perm['key'],
				'title'        => $perm['name'],
				'name'         => 'perm_'.$permId,
				'bold'         => $bold,
				'badgeClass'   => $badgeClass,
				'iconClass'    => $iconClass,
				'stateLabel'   => $stateLabel,
				'inheritRoles' => $inheritRoles,
				'values'       => [
					1 => [
						'title'    => $this->aLang['USER_ACL_ALLOW'],
						'selected' => ($selected === 1)
					],
					0 => [
						'title'    => $this->aLang['USER_ACL_DENY'],
						'selected' => ($selected === 0)
					],
					2 => [
						'title'    => $this->aLang['USER_ACL_IGNORED'],
						'selected' => ($selected === 2)
					]
				]
			];
		}

		/* =========================================
		   SORT
		========================================= */

		foreach ($grouped as $module => &$perms) {
			$overrideCount = 0;
			foreach ($perms as $perm) {
				if (!empty($perm['bold'])) {
					$overrideCount++;
				}
			}

			usort($perms, fn($a, $b) => strcasecmp($a['title'], $b['title']));

			$perms['overrideCount'] = $overrideCount;
		}
		unset($perms);

		uksort($grouped, function ($a, $b) use ($modules) {
			if ($a === 'others') return 1;
			if ($b === 'others') return -1;
			return array_search($a, $modules) <=> array_search($b, $modules);
		});

		/* =========================================
		   GROUP STATS
		========================================= */

		$aGroupStats = [];

		foreach ($grouped as $groupName => $permissions) {

			$total = count($permissions);
			$overridden = 0;

			foreach ($permissions as $permission) {

				if (
					$permission['values'][1]['selected'] === true ||
					$permission['values'][0]['selected'] === true
				) {
					$overridden++;
				}
			}

			$aGroupStats[$groupName] = [
				'overridden' => $overridden,
				'total'      => $total
			];
		}

		return [
			'user'          => $user,
			'headerTitle'   => sprintf($this->aLang['USER_ACL_MANAGING_FOR'], $user['username']),
			'aRoles'        => $rolesOut,
			'aPermsGrouped' => $grouped,
			'aGroupStats'   => $aGroupStats
		];
	}

	/**
	 * Save User Roles & Permission Overrides
	 *
	 * @param array $aData
	 * @return array
	 */
	public function saveUserEditData(array $aData): array
	{
		$form = $aData['form'] ?? [];

		$userId = (int)($form['id'] ?? 0);

		if ($userId < 1) {
			return [
				'success'    => false,
				'toastTitle' => $this->aLang['USER_ACL_THERE_IS_ERROR'],
				'toast'      => $this->aLang['USER_ACL_USERS_USER_ID_INVALID']
			];
		}

		$target   = $aData['target'] ?? 'aclUsers';
		$username = $this->getUsername($userId);

		$roles = [];
		$perms = [];

		foreach ($form as $k => $v) {

			if (strpos($k, 'role_') === 0) {
				$roles[] = (int)$v;
				continue;
			}

			if (strpos($k, 'perm_') === 0) {
				$permId = (int)str_replace('perm_', '', $k);
				$perms[$permId] = (int)$v;
			}
		}

		// =====================================================
		// ADMIN ROLE
		// =====================================================

		if (in_array(1, $roles, true)) {

			$this->oDb->query("
				DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_user_roles
				WHERE user_id = {$userId}
			");

			$this->oDb->query("
				INSERT INTO {$this->oDb->sTablePrefix}mod_user_acl_user_roles
				(user_id, role_id)
				VALUES ({$userId},1)
			");

			$this->oDb->query("
				DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_user_perms
				WHERE user_id = {$userId}
			");

			return [
				'success' => true,
				'a'       => $target,
				'toast'   => sprintf(
					$this->aLang['USER_ACL_USERS_ADMIN_ROLE_SET'],
					$username,
					1
				)
			];
		}

		// =====================================================
		// EXISTING ROLES
		// =====================================================

		$existingRoles = [];

		$res = $this->oDb->query("
			SELECT role_id
			FROM {$this->oDb->sTablePrefix}mod_user_acl_user_roles
			WHERE user_id = {$userId}
		");

		while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
			$existingRoles[] = (int)$row['role_id'];
		}

		$rolesToDelete = array_diff($existingRoles, $roles);
		$rolesToInsert = array_diff($roles, $existingRoles);

		if ($rolesToDelete) {

			$this->oDb->query("
				DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_user_roles
				WHERE user_id = {$userId}
				AND role_id IN (".implode(',', array_map('intval', $rolesToDelete)).")
			");
		}

		if ($rolesToInsert) {

			$values = [];

			foreach ($rolesToInsert as $r) {
				$values[] = "({$userId},".(int)$r.")";
			}

			$this->oDb->query("
				INSERT INTO {$this->oDb->sTablePrefix}mod_user_acl_user_roles
				(user_id, role_id)
				VALUES ".implode(',', $values)."
			");
		}

		$rolesChanged = count($rolesToInsert) + count($rolesToDelete);

		// =====================================================
		// EXISTING PERMISSION OVERRIDES
		// =====================================================

		$existingPerms = [];

		$res = $this->oDb->query("
			SELECT perm_id, value
			FROM {$this->oDb->sTablePrefix}mod_user_acl_user_perms
			WHERE user_id = {$userId}
		");

		while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
			$existingPerms[(int)$row['perm_id']] = (int)$row['value'];
		}

		$permChanges = 0;

		foreach ($perms as $permId => $value) {

			$permId = (int)$permId;
			$value  = (int)$value;

			// inherit
			if ($value === 2) {

				if (isset($existingPerms[$permId])) {

					$this->oDb->query("
						DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_user_perms
						WHERE user_id = {$userId}
						AND perm_id = {$permId}
					");

					$permChanges++;
				}

				continue;
			}

			if (
				!isset($existingPerms[$permId]) ||
				$existingPerms[$permId] !== $value
			) {

				$this->oDb->query("
					REPLACE INTO {$this->oDb->sTablePrefix}mod_user_acl_user_perms
					(user_id, perm_id, value)
					VALUES
					(
						{$userId},
						{$permId},
						{$value}
					)
				");

				$permChanges++;
			}
		}

		return [
			'success' => true,
			'a'       => $target,
			'toastTitle' => $this->aLang['USER_ACL_USERS'],
			'toast'   => sprintf(
				$this->aLang['USER_ACL_USERS_ROLES_AND_PERM_SET'],
				$rolesChanged,
				$permChanges,
				$username
			)
		];
	}	




































    /* ===================================================== */
    /* ================= USERS ============================== */
    /* ===================================================== */

    public function getUsername($iUserId): ?string
    {
        $sSql = 'SELECT username 
                 FROM `'.$this->oDb->sTablePrefix.'users`
                 WHERE user_id = '.(int)$iUserId;

        return $this->oDb->get_one($sSql);
    }
	
    public function getUsers(string $extraWhere = ''): ?array
    {
        $aOut = [];

        $sSql = 'SELECT user_id, username
                 FROM `'.$this->oDb->sTablePrefix.'users`
                 WHERE 1=1 '.$extraWhere.'
                 ORDER BY username ASC';

        if ($oRes = $this->oDb->query($sSql)) {
            while ($row = $oRes->fetchRow(MYSQLI_ASSOC)) {
                $aOut[] = [
                    'userId'   => (int)$row['user_id'],
                    'username' => $row['username']
                ];
            }
        }

        return $aOut;
    }

    /* ===================================================== */
    /* ================= PERMISSIONS ======================== */
    /* ===================================================== */

    public function editPermission($iPermId): ?array
    {
        if (!isset($this->permMap[$iPermId])) {
            return null;
        }

        return [
            'name' => $this->permMap[$iPermId]['name'],
            'key'  => $this->permMap[$iPermId]['key']
        ];
    }


    /* ===================================================== */
    /* ================= PERMISSIONS SLUG=================== */
    /* ===================================================== */
	
	function makeSlug($string) {
		$string = mb_strtolower($string, 'UTF-8');
		// normalize special letters
		$string = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
		$string = preg_replace('/[^a-z0-9\-_]+/', '_', $string);
		// merge multiples _ or -
		$string = preg_replace('/[_-]+/', '_', $string);
		$string = trim($string, '_-');
		return $string;
	}
	
    /* ===================================================== */
    /* ================= ROLES ============================== */
    /* ===================================================== */

    /**
     * All roles + if user has role
     */
    public function getUserRolesFull($iUserId): ?array
    {
        $aOut = [];
        $userRoles = [];

        $sSql = 'SELECT role_id 
                 FROM `'.$this->oDb->sTablePrefix.'mod_user_acl_user_roles`
                 WHERE user_id = '.(int)$iUserId;

        if ($oRes = $this->oDb->query($sSql)) {
            while ($row = $oRes->fetchRow(MYSQLI_ASSOC)) {
                $userRoles[] = (int)$row['role_id'];
            }
        }

        foreach ($this->roleMap as $id => $name) {
            $aOut[] = [
                'id'      => (int)$id,
                'name'    => $name,
                'checked' => in_array((int)$id, $userRoles, true)
            ];
        }

        return $aOut;
    }


	protected function syncAdminPermissions(): void
	{
		$res = $this->oDb->query("
			SELECT id
			FROM {$this->oDb->sTablePrefix}mod_user_acl_permissions
		");

		while ($p = $res->fetchRow(MYSQLI_ASSOC)) {
			$this->syncAdminPermission((int)$p['id']);
		}
	}

	protected function syncAdminPermission(int $permId): void
	{
		$exists = $this->oDb->get_one("
			SELECT 1
			FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
			WHERE role_id = 1
			AND perm_id = {$permId}
		");

		if ($exists) {

			$this->oDb->query("
				UPDATE {$this->oDb->sTablePrefix}mod_user_acl_role_perms
				SET value = 1
				WHERE role_id = 1
				AND perm_id = {$permId}
			");
		} else {
			$this->oDb->query("
				INSERT INTO {$this->oDb->sTablePrefix}mod_user_acl_role_perms
				(
					role_id,
					perm_id,
					value
				)
				VALUES
				(
					1,
					{$permId},
					1
				)
			");
		}
	}

	protected function saveRolePermissionValue(int $roleId, int $permId, int $value): void
	{
		if (!in_array($value, [0,1,2], true)) {
			return;
		}
		// ignore
		if ($value === 2) {
			$this->oDb->query("
				DELETE FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
				WHERE role_id = {$roleId}
				AND perm_id = {$permId}
			");
			return;
		}
		$exists = $this->oDb->get_one("
			SELECT 1
			FROM {$this->oDb->sTablePrefix}mod_user_acl_role_perms
			WHERE role_id = {$roleId}
			AND perm_id = {$permId}
		");
		if ($exists) {
			$this->oDb->query("
				UPDATE {$this->oDb->sTablePrefix}mod_user_acl_role_perms
				SET value = {$value}
				WHERE role_id = {$roleId}
				AND perm_id = {$permId}
			");
		} else {
			$this->oDb->query("
				INSERT INTO {$this->oDb->sTablePrefix}mod_user_acl_role_perms
				(
					role_id,
					perm_id,
					value
				)
				VALUES
				(
					{$roleId},
					{$permId},
					{$value}
				)
			");
		}
	}

    /* ===================================================== */
    /* ================= DEBUG ============================== */
    /* ===================================================== */

    public function getErrorCount(): int
    {
        return (int)($this->oDb->get_one(
            "SELECT COUNT(*) FROM `".$this->oDb->sTablePrefix."mod_user_acl_errors`"
        ) ?? 0);
    }

    public function getErrorsList(): ?array
    {
        $aOut = [];

        $sSql = 'SELECT * 
                 FROM `'.$this->oDb->sTablePrefix.'mod_user_acl_errors`
                 ORDER BY created_at DESC';

        if ($oRes = $this->oDb->query($sSql)) {
            while ($row = $oRes->fetchRow(MYSQLI_ASSOC)) {
                $aOut[] = [
                    'key'     => $row['perm_key'],
                    'message' => nl2br(str_replace(WB_PATH, '', $row['message'])),
                    'date'    => date("H:i d.m.Y", strtotime($row['created_at']) + $this->oReg->Timezone)
                ];
            }
        }

        return $aOut;
    }
	
	
	
	


	







	public function getPermsGrouped(): array
	{
		$allPerms = $this->getAllPerms();
		$modules  = $this->getInstalledModules();

		if (empty($allPerms)) {
			return [
				'modules' => [],
				'grouped' => []
			];
		}

		$moduleOrder = array_flip($modules);
		$grouped = [];

		foreach ($allPerms as $p) {

			$module = 'others';

			// koristi format: module.action
			if (!empty($p['key']) && strpos($p['key'], '.') !== false) {
				[$module] = explode('.', $p['key'], 2);
			}

			// fallback ako modul ne postoji u addons
			if (!isset($moduleOrder[$module])) {
				$module = 'others';
			}

			$grouped[$module][] = [
				'id'    => (int)$p['id'],
				'key'   => $p['key'],
				'name'  => $p['name'],
				'value' => 2 // default (ignore)
			];
		}

		// sortiraj permise po imenu
		foreach ($grouped as &$perms) {
			usort($perms, fn($a, $b) => strcasecmp($a['name'], $b['name']));
		}
		unset($perms);

		// sortiraj module po addons redu
		uksort($grouped, function ($a, $b) use ($moduleOrder) {
			return ($moduleOrder[$a] ?? 999) <=> ($moduleOrder[$b] ?? 999);
		});

		return [
			'modules' => $modules,
			'grouped' => $grouped
		];
	}

	
	/**
	 * Clear ACL error log
	 *
	 * @return array
	 */
	public function clearLog(): array
	{
		$this->oDb->query("
			TRUNCATE TABLE {$this->oDb->sTablePrefix}mod_user_acl_errors
		");

		return [
			'success' 		=> true,
			'toastTitle'   	=> $this->aLang['USER_ACL_ERROR_LOG_CLEARED'],
			'toast'   		=> $this->aLang['USER_ACL_ERROR_LOG_CLEARED'],
			'out'   		=> $this->aLang['USER_ACL_ERROR_LOG_CLEARED']
		];
	}	
}