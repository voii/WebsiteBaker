-- <?php header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; flush(); exit;?>
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 24, 2026 at 09:04 AM
-- Server version: 5.6.51
-- PHP Version: 8.1.7
--
-- Data for Table `{TABLE_PREFIX}mod_user_acl_permissions`
--
INSERT INTO `{TABLE_PREFIX}mod_user_acl_permissions` (`id`, `perm_key`, `perm_name`) VALUES
(1, 'user_acl_view', 'ACL View'),
(2, 'user_acl_manage_users', 'ACL Manage Users'),
(3, 'user_acl_view_roles', 'ACL View Roles'),
(4, 'user_acl_manage_roles', 'ACL Manage Roles'),
(5, 'user_acl_view_permissions', 'ACL View Permissions'),
(6, 'user_acl_manage_permissions', 'ACL Manage Permissions');
--
-- Data for Table `{TABLE_PREFIX}mod_user_acl_roles`
--
INSERT INTO `{TABLE_PREFIX}mod_user_acl_roles` (`id`, `role_name`, `role_data`) VALUES
(1, 'Administrator','Full access to every feature','admin');
--
-- Data for Table `{TABLE_PREFIX}mod_user_acl_role_perms`
--
INSERT INTO `{TABLE_PREFIX}mod_user_acl_role_perms` (`role_id`, `perm_id`, `value`) VALUES
(1, 1, 1),
(1, 2, 1),
(1, 3, 1),
(1, 4, 1),
(1, 5, 1),
(1, 6, 1);
--
