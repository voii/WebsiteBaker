-- <?php header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; flush(); exit;?>
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 24, 2026 at 09:04 AM
-- Server version: 5.6.51
-- PHP Version: 8.1.7
--
SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
-- --------------------------------------------------------
--
-- Replacements: {TABLE_PREFIX}, {TABLE_ENGINE}, {FIELD_COLLATION}
--
-- --------------------------------------------------------
-- PERMISSIONS Table `mod_user_acl_permissions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `{TABLE_PREFIX}mod_user_acl_permissions`;
CREATE TABLE `{TABLE_PREFIX}mod_user_acl_permissions` (
  `id` INT UNSIGNED AUTO_INCREMENT,
  `perm_key` VARCHAR(191) NOT NULL,
  `perm_name` VARCHAR(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_perm_key` (`perm_key`)
) {TABLE_ENGINE};
--
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- ROLES Table `mod_user_acl_roles`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `{TABLE_PREFIX}mod_user_acl_roles`;
CREATE TABLE `{TABLE_PREFIX}mod_user_acl_roles` (
  `id` INT UNSIGNED AUTO_INCREMENT,
  `role_name` VARCHAR(191) NOT NULL,
  `role_description` VARCHAR(191) NULL,
  `created_by` VARCHAR(191) NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_name` (`role_name`)
) {TABLE_ENGINE};
--
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- ROLE PERMISSIONS Table `mod_user_acl_role_perms`
-- --------------------------------------------------------
--
DROP TABLE IF EXISTS `{TABLE_PREFIX}mod_user_acl_role_perms`;
CREATE TABLE `{TABLE_PREFIX}mod_user_acl_role_perms` (
  `role_id` INT UNSIGNED NOT NULL,
  `perm_id` INT UNSIGNED NOT NULL,
  `value` TINYINT(1) NOT NULL DEFAULT 0,

  PRIMARY KEY (`role_id`, `perm_id`),

  CONSTRAINT `fk_role_perms_role`
    FOREIGN KEY (`role_id`)
    REFERENCES `{TABLE_PREFIX}mod_user_acl_roles` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT `fk_role_perms_perm`
    FOREIGN KEY (`perm_id`)
    REFERENCES `{TABLE_PREFIX}mod_user_acl_permissions` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) {TABLE_ENGINE};
--
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- USER PERMISSIONS Table `mod_user_acl_user_perms`
-- --------------------------------------------------------
--
DROP TABLE IF EXISTS `{TABLE_PREFIX}mod_user_acl_user_perms`;
CREATE TABLE `{TABLE_PREFIX}mod_user_acl_user_perms` (
  `user_id` INT UNSIGNED NOT NULL,
  `perm_id` INT UNSIGNED NOT NULL,
  `value` TINYINT(1) NOT NULL DEFAULT 0,

  PRIMARY KEY (`user_id`, `perm_id`),

  CONSTRAINT `fk_user_perms_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `{TABLE_PREFIX}users` (`user_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT `fk_user_perms_perm`
    FOREIGN KEY (`perm_id`)
    REFERENCES `{TABLE_PREFIX}mod_user_acl_permissions` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) {TABLE_ENGINE};
--
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- USER ROLES Table `mod_user_acl_user_roles`
-- --------------------------------------------------------
--
DROP TABLE IF EXISTS `{TABLE_PREFIX}mod_user_acl_user_roles`;
CREATE TABLE `{TABLE_PREFIX}mod_user_acl_user_roles` (
  `user_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,

  PRIMARY KEY (`user_id`, `role_id`),

  CONSTRAINT `fk_user_roles_user`
    FOREIGN KEY (`user_id`)
    REFERENCES `{TABLE_PREFIX}users` (`user_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,

  CONSTRAINT `fk_user_roles_role`
    FOREIGN KEY (`role_id`)
    REFERENCES `{TABLE_PREFIX}mod_user_acl_roles` (`id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) {TABLE_ENGINE};
--
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- ERRORS LOG Table `mod_user_acl_user_roles`
-- --------------------------------------------------------
--
DROP TABLE IF EXISTS `{TABLE_PREFIX}mod_user_acl_errors`;
CREATE TABLE `{TABLE_PREFIX}mod_user_acl_errors` (
  `id` INT UNSIGNED AUTO_INCREMENT,
  `perm_key` VARCHAR(191) NOT NULL,
  `message` TEXT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_perm_key` (`perm_key`)
) {TABLE_ENGINE};

SET FOREIGN_KEY_CHECKS = 1;

--
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- Settings Table `mod_user_acl_settings`
-- --------------------------------------------------------
--
DROP TABLE IF EXISTS `{TABLE_PREFIX}mod_user_acl_settings`;
CREATE TABLE `{TABLE_PREFIX}mod_user_acl_settings` (
    `setting_key`   VARCHAR(80) NOT NULL,
    `setting_value` TEXT NOT NULL,
    PRIMARY KEY (`setting_key`)
) {TABLE_ENGINE};