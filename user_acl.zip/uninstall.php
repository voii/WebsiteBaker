<?php


use bin\{WbAdaptor,SecureTokens,Sanitize};
use bin\helpers\{PreCheck,msgQueue};
use src\Security\{CsfrTokens,Randomizer};
use src\Interfaces\Requester;
use bin\Requester\HttpRequester;

if (!\defined('SYSTEM_RUN')) {\header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; flush(); exit; }

    $msg = [];
    $sErrorMsg = null;	
    $sAddonPath = \str_replace(DIRECTORY_SEPARATOR, '/', __DIR__);	
    $sAddonName = basename($sAddonPath);
// check if upgrade startet by upgrade-script to echo a message
    $globalStarted = preg_match('/upgrade\-script\.php$/', $_SERVER["SCRIPT_NAME"]);
    $sWbVersion = ($globalStarted && defined('VERSION') ? VERSION : WB_VERSION);
    $sModulePlatform = PreCheck::getAddonVariable($sAddonName,'platform');
    if (version_compare($sWbVersion, $sModulePlatform, '<')){
        $msg[] = $sErrorMsg = sprintf('It is not possible to install from WebsiteBaker Versions before %s',$sModulePlatform);
        if ($globalStarted){
            echo $sErrorMsg;
        }else{
            throw new Exception ($sErrorMsg);
        }
    } else {

		// Check If USER can uninstall MODULE
		$iMe = $admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0);
		$aclOwners = new \addon\user_acl\AclOwners();

		// $admin->ami_group_member('1')
        if ($admin->is_authenticated() && $aclOwners->isOwner($iMe)) {

			// create tables from sql dump file

			if (is_readable($sAddonPath.'/sql/install-struct.sql.php')) {
				$oReg->Db->SqlImport($sAddonPath.'/sql/install-struct.sql.php', TABLE_PREFIX, 'uninstall' );
			}
			if (is_readable($sAddonPath.'/sql/install-data.sql.php')) {
				$oReg->Db->SqlImport($sAddonPath.'/sql/install-data.sql.php', TABLE_PREFIX, 'uninstall' );
			}
			if ($oReg->Db->is_error()){
				$msg[] = 'ACL MODULE ERROR::'.$oReg->Db->get_error();
			}
		
		   
        } else {
			$sErrorMsg = 'You must be admin with ID: 1 to be able to uninstall and use this module';
			throw new Exception ($sErrorMsg);
		}
    }