import { Toast } from '../../../templates/Bebsa/js/bootstrap-toaster.js';

class acl {
		
	constructor(settings) {

		this.settings = settings;	
		this.defaults = {
			_mc: "acp_pages_container",
			_loader: '<div class="spinner-border m-5" role="status"><span class="visually-hidden">Loading...</span></div>',
			_firstLoad: false,
			_parentContainer: null,
			_aMsgs: null,
			_iSearchTimeout: null
		};		
		this.build();
	}

	_actions (a, p, callback) {
			
		const $t = this;
		
		$t.mc = document.getElementById($t.settings._mc);
		$t.loader = $t.settings._loader;
		
		let t = null;

		if (a) {
			if(typeof a === 'string') { a = [a];}
			let v = p || {}	
			a.forEach(function(e) {
				switch (e) {
				  case '#':
						return !1;					  
					break;
				  case 'start':
						v = { action: e	}
						$t._fetchData(v).then((r) => {
							$t.settings._aMsgs = r.out;
							if (!$t.settings._firstLoad) $t.settings._firstLoad = true;
						})
					break;

				  case 'aclRoles':
				  case 'search':
				  case 'aclUsers':
				  case 'aclPermissions':
				  case 'aclSettingsUsers':
				  case 'aclSettingsGroups':
						t = document.getElementById(e);
						t.innerHTML = $t.loader;
						v = { action: e }
						if (p) v.sQ = p.q;
						$t._fetchData(v).then((r) => {
							t.innerHTML = r.out;
							if (p && p.q){							
								let st = 2;
								if (r.s) st = 1;
								let toast = {
									title: r.toastTitle,
									message: r.toast,
									status: st,
									timeout: 3000
								}
								Toast.create(toast);
							}
						})
					break;					

				  case 'aclPermEdit':
				  case 'aclRoleEdit':
				  case 'aclCompareRoles':
				  case 'aclUserEdit':
						t = document.getElementById(p.target);
						t.innerHTML = $t.loader;
						v = { action: e, iId: p.id }
						$t._fetchData(v).then((r) => {
							t.innerHTML = r.out;
							if (!r.s){	
								let toast = {
									title: r.toastTitle,
									message: r.toast,
									status: 2,
									timeout: 3000
								}
								Toast.create(toast);	
							}
						})
					break;

				  case 'aclPermissionSave':
				  case 'aclRoleSave':
				  case 'aclSettingsUsersSave':
				  case 'aclSettingsGroupsSave':				  
						t = document.getElementById(p.target);
						t.innerHTML = $t.loader;
						v = { action: e, aData: p }
						$t._fetchData(v).then((r) => {
							$t._actions([r.a]);
							let st = 2;
							if (r.s) st = 1;
							let toast = {
								title: r.toastTitle,
								message: r.toast,
								status: st,
								timeout: 3000
							}
							Toast.create(toast);
						})
					break;	

				  case 'aclUserSave':
						t = document.getElementById(p.target);
						t.innerHTML = $t.loader;
						v = { action: e, aData: p }
						$t._fetchData(v).then((r) => {
							let st = 2;
							if (r.s) st = 1;
							let toast = {
								id: r.id,
								title: r.toastTitle,
								message: r.toast,
								status: st,
								timeout: 0
							}
							Toast.create(toast);
							$t._actions(r.a);
						})
					break;							
					
				  case 'aclPermissionDeleteConfim':
				  case 'aclRoleDeleteConfim':
						t = document.getElementById(p.target);
						t.innerHTML = $t.loader;
						v = { action: e, aData: p }
						$t._fetchData(v).then((r) => {
							if (r.a) $t._actions([r.a]);
							if (r.h) t.innerHTML = $t.loader+' '+r.h;
							let st = 2;
							if (r.s) st = 1;
							let toast = {
								id: r.id,
								title: r.toastTitle,
								message: r.toast,
								status: st,
								timeout: 0
							}
							Toast.create(toast);
						})
					break;					
					
					
				  case 'aclPermissionDelete':
				  case 'aclRoleDelete':
						t = document.getElementById(p.target);
						t.innerHTML = $t.loader;
						v = { action: e, aData: p }
						$t._fetchData(v).then((r) => {
							let st = 2;
							if (r.s) st = 1;
							let toast = {
								id: r.id,
								title: r.toastTitle,
								message: r.toast,
								status: st,
								timeout: 3000
							}
							Toast.create(toast);
							$t._actions(r.a);
						})
					break;	
					
				  case 'aclClearLog':
						$t.mc.innerHTML = $t.loader;
						v = { action: e }
						$t._fetchData(v).then((r) => {
							$t.mc.innerHTML = r.out;
							let st = 2;
							if (r.s) st = 1;
							let toast = {
								title: r.toastTitle,
								message: r.toast,
								status: st,
								timeout: 3000
							}
							Toast.create(toast);
						})
					break;

				  default:
					console.log(`Sorry, we are out of ${a}.`);
				}
			});
		}				
	}
	
	init() {
		
		const $t = this;
		
		if (!$t.settings) {
			$t.settings = $t.defaults;
		}
		for (var [key, value] of Object.entries($t.defaults)) {
			if (!$t.settings[key]) {
				$t.settings[key] = value;
			}
		}		
	
		$t._actions(['start']);
		
		
		$t.settings._parentContainer = this._select('#acp');
		$t.settings._parentContainer.addEventListener('click', function(ev) {
			let el = ev.srcElement,
				o = {};	
				
			if (el = $t.getClosest(ev.target, '[data-acl-action]')){
				$t._preventDefaults(ev);
				o.action = el.dataset.aclAction;
				if (el.hasAttribute("data-acl-id")) {
					o.id = el.dataset.aclId;
				}
				$t._actions(o.action, o);	
				return;
			}

			if (el = $t.getClosest(ev.target, '[data-acl]')){
				$t._preventDefaults(ev);
				o.action = el.dataset.acl;
				if (el.hasAttribute("data-acl-id")) {
					o.id = el.dataset.aclId;
				}
				if (el.hasAttribute("data-acl-target")) {
					o.target = el.dataset.aclTarget;
				}
				$t._actions(o.action, o);	
				return;
			}
			
			if (el = $t.getClosest(ev.target, '[data-acl-reload]')){
				$t._preventDefaults(ev);
				o.action = el.dataset.aclReload;
				const searchInput = document.querySelector(`[data-acl-search="${o.action}"]`);
				if (searchInput) { searchInput.value = '';}
				$t._actions(o.action, o);	
				return;
			}				

			if (el = $t.getClosest(ev.target, '[data-acl-save]')){
				$t._preventDefaults(ev);
				o.action = el.dataset.aclSave;
				if (el.hasAttribute("data-acl-target")) {
					o.target = el.dataset.aclTarget;
				}
				let f = $t.getClosest(ev.target, 'form');
				o.form = $t._formDataToObject(f);
				$t._actions(o.action, o);	
				return;
			}

			if (el = $t.getClosest(ev.target, '[data-acl-toclipboard]')){
				$t._preventDefaults(ev);
				let t = el.dataset.aclToclipboard;

				const textarea = document.createElement('textarea');
				textarea.value = t;
				textarea.style.position = 'fixed';
				textarea.style.opacity = '0';

				document.body.appendChild(textarea);
				textarea.focus();
				textarea.select();

				try {
				const successful = document.execCommand('copy');
					if (successful) {
						const icon = document.createElement('i');
						icon.className = 'bi bi-check-lg ms-2 text-success';
						el.appendChild(icon);

						let toast = {
							title: $t.settings._aMsgs.TT,
							message: $t.settings._aMsgs.TMC+' <u>'+t+'</u>',
							status: 1,
							timeout: 3000
						}
						Toast.create(toast);

						// Uklanjanje nakon 3 sekunde
						setTimeout(() => {
							icon.remove();
						}, 3000);
						console.log('Clipboard copy:', t);
					}
				} catch (err) {
					console.error('Error copy to clipboard:', err);
				}
				document.body.removeChild(textarea);
				return;
			}
		});
		
		$t.settings._parentContainer = this._select('body');
		$t.settings._parentContainer.addEventListener('click', function(ev) {	
			let el = ev.srcElement,
				o = {};	
				
			if (el = $t.getClosest(ev.target, '[data-acl-confirm]')){
				$t._preventDefaults(ev);
				o.action = el.dataset.aclConfirm;
				o.id = el.dataset.aclId;
				o.target = el.dataset.aclTarget;					
				$t._actions(o.action, o);					
				const myToastEl = document.getElementById(el.dataset.aclToastId) 
				const myToast = bootstrap.Toast.getOrCreateInstance(myToastEl)
				myToast.hide();
				return;
			}
			
			if (el = $t.getClosest(ev.target, '[data-acl-confirm-cancel]')){
				$t._preventDefaults(ev);
				o.action = el.dataset.aclConfirmCancel;
				$t._actions(o.action, o);					
				const myToastEl = document.getElementById(el.dataset.aclToastId);
				const myToast = bootstrap.Toast.getOrCreateInstance(myToastEl)
				myToast.hide();
				return;
			}

			if (el = $t.getClosest(ev.target, '[data-acl-allow-all]')) {
				$t._preventDefaults(ev);
				const target = document.querySelector(el.dataset.aclAllowAll);
				if (!target) return;
				target.querySelectorAll('[data-perm-row]').forEach((row) => {
					if (row.classList.contains('acl-hidden')) return;
					const select = row.querySelector('select[data-perm-select]');
					if (select) select.value = '1';
				});
				$t._updatePermCounter(target);
				return;
			}
			if (el = $t.getClosest(ev.target, '[data-acl-deny-all]')) {
				$t._preventDefaults(ev);
				const target = document.querySelector(el.dataset.aclDenyAll);
				if (!target) return;
				target.querySelectorAll('[data-perm-row]').forEach((row) => {
					if (row.classList.contains('acl-hidden')) return;

					const select = row.querySelector('select[data-perm-select]');
					if (select) select.value = '0';
				});
				$t._updatePermCounter(target);
				return;
			}
			if (el = $t.getClosest(ev.target, '[data-acl-ignore-all]')) {
				$t._preventDefaults(ev);
				const target = document.querySelector(el.dataset.aclIgnoreAll);
				if (!target) return;
				target.querySelectorAll('[data-perm-row]').forEach((row) => {
					if (row.classList.contains('acl-hidden')) return;

					const select = row.querySelector('select[data-perm-select]');
					if (select) select.value = '2';
				});
				$t._updatePermCounter(target);
				return;
			}
		});
		
		document.addEventListener("click", function (e) {
			var elems = document.querySelectorAll(".item_box");
			[].forEach.call(elems, function(el) {
				el.classList.remove("active");
			});
		});


		$t.settings._parentContainer.addEventListener('keyup', function(ev) {
			let el = ev.srcElement,
				o = {};
				
			if (el = $t.getClosest(ev.target, '[data-acl-search]')){
				o.action = el.dataset.aclSearch;
				
				clearTimeout($t._iSearchTimeout);
				$t._iSearchTimeout = setTimeout(function() {
					o.q = el.value;
					$t._actions(o.action, o);
				  }, 800);
				return !1;
			}
			
			if (el = $t.getClosest(ev.target, '[data-acl-perm-filter]')) {
				clearTimeout($t._permFilterTimeout);
				$t._permFilterTimeout = setTimeout(() => {
					const q = el.value.toLowerCase().trim();
					const accordion = document.getElementById(el.dataset.aclPermFilter);
					if (!accordion) return;
					accordion.querySelectorAll('.accordion-item').forEach((item) => {
						let found = 0;
						item.querySelectorAll('[data-perm-row]').forEach((row) => {
							const text = (row.dataset.permText || '').toLowerCase();
							const match =
								!q ||
								text.includes(q);
							row.classList.toggle('acl-hidden', !match);
							if (match) found++;
						});
						item.classList.toggle('acl-hidden', found === 0);
						const collapse = item.querySelector('.accordion-collapse');
						if (collapse) {
							if (q && found > 0) {
								collapse.classList.add('show');
							}
						}
					});
				}, 200);
				return;
			}
		});
		
		$t.settings._parentContainer.addEventListener('change', function(ev) {
			let el = ev.srcElement;

			if (el = $t.getClosest(ev.target, '[data-perm-select]')) {
				const accordion = $t.getClosest(el, '.accordion-item');
				if (!accordion) return;
				$t._updatePermCounter(accordion);
				return;
			}
		});			
	}

	_updatePermCounter(wrapper) {			
		if (!wrapper) return;
		const accordionItem = wrapper.closest('.accordion-item');
		if (!accordionItem) return;
		const selects = accordionItem.querySelectorAll('select[data-perm-select]');
		let enabled = 0;
		let total = selects.length;
		selects.forEach((s) => {
			// 0 = deny
			// 1 = allow
			// 2 = ignore
			if (s.value !== '2') {
				enabled++;
			}
		});
		const badge = accordionItem.querySelector('[data-perm-counter]');
		if (badge) {
			badge.innerText = `${enabled}/${total}`;
		}
	}


	
	getClosest = function (elem, selector) {
		for ( ; elem && elem !== document; elem = elem.parentNode ) {
			if ( elem.matches( selector ) ) return elem;
		}
		return null;
	}

	build() {
		let $t = this;		
		$t.init();

	}
	
	_select (el, all = false) {
		el = el.trim()
		if (all) {
			return [...document.querySelectorAll(el)]
		} else {
			return document.querySelector(el)
		}
	}

	_on (type, el, listener, all = false) {
		let selectEl = this._select(el, all)
			if (selectEl) {
			if (all) {
				selectEl.forEach(e => e.addEventListener(type, listener))
			} else {
				selectEl.addEventListener(type, listener)
			}
		}
	}
	_preventDefaults(e) { e.preventDefault(); e.stopPropagation(); }

	_formDataToObject(form)
	{
		const fd = new FormData(form);
		const obj = {};
		for (const [key, value] of fd.entries()) {
			// if array field (checkbox[] / input[])
			if (key.endsWith('[]')) {
				if (!Array.isArray(obj[key])) {
					obj[key] = [];
				}
				obj[key].push(value);
				continue;
			}
			// if same key mulitple times
			if (Object.prototype.hasOwnProperty.call(obj, key)) {
				if (!Array.isArray(obj[key])) {
					obj[key] = [obj[key]];
				}
				obj[key].push(value);
				continue;
			}
			obj[key] = value;
		}
		return obj;
	}

	async _fetchData(p) {
		try {
			const token = window.App.csrfToken;
			if (!token || !token.name || !token.value) {
				console.warn('No CSRF token');
				return;
			}
			const response = await fetch(WB_URL + '/modules/user_acl/ajax/ajax.php', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'Cache-Control': 'no-cache',
					'X-CSRF-TOKEN': token.name,
				},
				body: JSON.stringify(p)
			});
			if (!response.ok) {
				throw new Error("Fetch error");
			}
			const data = await response.json();
			if (data.newFtan) {
				window.App.csrfToken = data.newFtan;
			}
			if (data.success === false && data.refreshRequired) {
				Toast.create({
					title: data.title,
					message: data.toast,
					status: 2,
					timeout: 3000
				});
			}
			return data;
		} catch (err) {
			console.warn('Fetch error', err);
			return null;
		}
	}	
}
export { acl };