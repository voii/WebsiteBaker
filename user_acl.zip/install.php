<?php


use bin\{WbAdaptor,SecureTokens,Sanitize};
use bin\helpers\{PreCheck,msgQueue};
use src\Security\{CsfrTokens,Randomizer};
use src\Interfaces\Requester;
use bin\Requester\HttpRequester;

if (!\defined('SYSTEM_RUN')) {\header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; flush(); exit; }

    $msg = [];
    $sErrorMsg = null;	
    $sAddonPath = \str_replace(DIRECTORY_SEPARATOR, '/', __DIR__);	
    $sAddonName = basename($sAddonPath);
// check if upgrade startet by upgrade-script to echo a message
    $globalStarted = preg_match('/upgrade\-script\.php$/', $_SERVER["SCRIPT_NAME"]);
    $sWbVersion = ($globalStarted && defined('VERSION') ? VERSION : WB_VERSION);
    $sModulePlatform = PreCheck::getAddonVariable($sAddonName,'platform');
    if (version_compare($sWbVersion, $sModulePlatform, '<')){
        $msg[] = $sErrorMsg = sprintf('It is not possible to install from WebsiteBaker Versions before %s',$sModulePlatform);
        if ($globalStarted){
            echo $sErrorMsg;
        }else{
            throw new Exception ($sErrorMsg);
        }
    } else {

		// Check If USER_ID = 1
        if ($admin->is_authenticated() && $admin->ami_group_member('1')) {

			// create tables from sql dump file

			if (is_readable($sAddonPath.'/sql/install-struct.sql.php')) {
				$oReg->Db->SqlImport($sAddonPath.'/sql/install-struct.sql.php', TABLE_PREFIX, 'install' );
			}
			if (is_readable($sAddonPath.'/sql/install-data.sql.php')) {
				$oReg->Db->SqlImport($sAddonPath.'/sql/install-data.sql.php', TABLE_PREFIX, 'install' );
			}
			if ($oReg->Db->is_error()){
				$msg[] = 'ACL MODULE ERROR::'.$oReg->Db->get_error();
			}
			
			// Assign user to Administrator role
			$iUserId = $admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0);	
			if ($iUserId > 0){
				$oDb->query("
					INSERT IGNORE INTO `".TABLE_PREFIX."mod_user_acl_user_roles`
					(user_id, role_id)
					VALUES ({$iUserId}, 1) ");
			}
		   
			// Create module owner - user and group
			$sGroupsId = $oDb->get_one("SELECT `groups_id` FROM `".TABLE_PREFIX."users` WHERE `user_id` = {$iUserId} "); // example "1" or "2,5,7,1"
			$aGroups = array_map('intval', explode(',', $sGroupsId));
			$minGroupId = min($aGroups); // Admin group		
			$oDb->query("
				INSERT INTO `".TABLE_PREFIX."mod_user_acl_settings`
				(`setting_key`, `setting_value`)
				VALUES ('owner_user_ids', {$iUserId}) ");
			$oDb->query("
				INSERT INTO `".TABLE_PREFIX."mod_user_acl_settings`
				(`setting_key`, `setting_value`)
				VALUES ('owner_group_ids', {$minGroupId}) ");
		   
        } else {
			$sErrorMsg = 'You must be admin with ID: 1 to be able to install and use this module';
			throw new Exception ($sErrorMsg);
		}
    }