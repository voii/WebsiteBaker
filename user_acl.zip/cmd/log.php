<?php


// use bin\{WbAdaptor,SecureTokens,Sanitize};
// use bin\helpers\{PreCheck};
use addon\user_acl\AclBe;

/* -------------------------------------------------------- */
// Must include code to stop this file being accessed directly
if (!\defined('SYSTEM_RUN')) {\header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; \flush(); exit; }
/* -------------------------------------------------------- */

$aTplDefaults = [];

if ($myACL->can('user_acl_access')) {

/** Output **/
$aAclOverviewLog = [
	'sLog'	=> $myACL->getErrorsList(),
	'aLang' => $aLang
];

$aTplDefaults['ACL_OVERVIEW_LOG'] = '';
if (is_readable($sAddonThemePath.'/acl_error_log.twig'))
{	
	if ($aTplDefaults['ACL_OVERVIEW_LOG'] != ''){
		ob_start();
		$oTpl = $oTwig->createTemplate($aTplDefaults['ACL_OVERVIEW_LOG']);
		$sPermissions = $oTpl->display($aAclOverviewLog);
		$sPermissions = \ob_get_clean();
	} else {
		$sPermissions = $oTwig->render('acl_error_log.twig', $aAclOverviewLog);              
	}
	
}

$sMain = $sPermissions;

} else {
	echo $aLang['USER_ACL_NO_PERMISSION_FOR_MODULE'];
} 
