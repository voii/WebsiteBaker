<?php


// use bin\{WbAdaptor,SecureTokens,Sanitize};
// use bin\helpers\{PreCheck};
use addon\user_acl\{AclBe, AclOwners};

/* -------------------------------------------------------- */
// Must include code to stop this file being accessed directly
if (!\defined('SYSTEM_RUN')) {\header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; \flush(); exit; }
/* -------------------------------------------------------- */

$aTplDefaults = [];

$aclOwners = new \addon\user_acl\AclOwners();
$isOwner = $aclOwners->isOwner($admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0));

function renderTwig($twig, $templatePath, $templateName, $data, $templateOverride = '')
{
    if (!is_readable($templatePath.'/'.$templateName)) {
        return '';
    }

    if (!empty($templateOverride)) {
        ob_start();
        $tpl = $twig->createTemplate($templateOverride);
        $tpl->display($data);
        return ob_get_clean();
    }

    return $twig->render($templateName, $data);
}

if ($myACL->can('user_acl_access') && $isOwner) {

	$html = '';

	$q = '';

	/** Users **/
	$sUsers = renderTwig(
		$oTwig,
		$sAddonThemePath,
		'acl_settings_users.twig',
		[
			'aUsers'	=> $aclOwners->getOwnerUsers($q),
			'aLang'     => $aLang,
		],
		$aTplDefaults['ACL_USERS'] ?? ''
	);
	
	/** Groups **/
	$sGroups = renderTwig(
		$oTwig,
		$sAddonThemePath,
		'acl_settings_groups.twig',
		[
			'aGroups'	=> $aclOwners->getOwnerGroups($q),
			'aLang'     => $aLang,
		],
		$aTplDefaults['ACL_GROUPS'] ?? ''
	);
	
		
	/** Output **/
	$aOut = [
		'sUsers'			=> $sUsers,
		'sGroups'			=> $sGroups,
		'aLang' 			=> $aLang,
	];

	$sOut = renderTwig(
		$oTwig,
		$sAddonThemePath,
		'acl_settings.twig',
		$aOut,
		$aTplDefaults['ACL_SETTINGS'] ?? ''
	);
	$sMain = $sOut;

} else {
	echo $aLang['USER_ACL_NO_PERMISSION_FOR_MODULE'];
} 
