<?php


// use bin\{WbAdaptor,SecureTokens,Sanitize};
// use bin\helpers\{PreCheck};
use addon\user_acl\{AclBe, AclIntegrity};

/* -------------------------------------------------------- */
// Must include code to stop this file being accessed directly
if (!\defined('SYSTEM_RUN')) {\header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; \flush(); exit; }
/* -------------------------------------------------------- */

$aTplDefaults = [];

$aclIntegrity = new AclIntegrity();

function renderTwig($twig, $templatePath, $templateName, $data, $templateOverride = '')
{
    if (!is_readable($templatePath.'/'.$templateName)) {
        return '';
    }
    if (!empty($templateOverride)) {
        ob_start();
        $tpl = $twig->createTemplate($templateOverride);
        $tpl->display($data);
        return ob_get_clean();
    }
    return $twig->render($templateName, $data);
}


if ($myACL->can('user_acl_access')) {

	/** Roles **/
	$sRolesList = '';
	if ($myACL->can('user_acl_view_roles')) {
		$aRoles = $myACL->getRolesOverview();
		$sRolesList = renderTwig(
			$oTwig,
			$sAddonThemePath,
			'acl_roles_list.twig',
			[
				'aRoles'     => $aRoles,
				'modules'   => $myACL->getInstalledModules(),
				'aLang'     => $aLang,
				'bCanManage' => $myACL->can('user_acl_manage_roles'),
			],
			$aTplDefaults['ACL_ROLES_LIST'] ?? ''
		);
	}

	/** Permissions **/
	$sPermissionsList = '';
	if ($myACL->can('user_acl_view_permissions')) {
		$aPermissions = $myACL->getPermissionsOverview();
		foreach ($aPermissions as &$group) {
			foreach ($group as &$perm) {			
				$perm['can_manage'] = $myACL->can('user_acl_manage_permissions');
				$perm['can_edit'] =
					$perm['can_manage']
					&& $aclIntegrity->isPermissionEditable(
						$perm['key'],
						$myACL->iUserId
					);
			}
		}
		unset($group, $perm);	
		$sPermissionsList = renderTwig(
			$oTwig,
			$sAddonThemePath,
			'acl_permission_list.twig',
			[
				'aPermissions' => $aPermissions,
				'aLang'        => $aLang,
			],
			$aTplDefaults['ACL_PERMISSION_LIST'] ?? ''
		);
	}

	/** Users **/	
	$sUsers = '';
	if ($myACL->can('user_acl_manage_users')) {
		$sUsers = renderTwig(
			$oTwig,
			$sAddonThemePath,
			'acl_users_list.twig',
			[
				'aUsers' => $myACL->getUsersWithRolesAndPerms(),
				'aLang'  => $aLang,
				'bCanManage' => $myACL->can('user_acl_manage_users')
			],
			$aTplDefaults['ACL_USERS_LIST'] ?? ''
		);
	}	

	$canView 				= $myACL->can('user_acl_access');
	$canViewPermissions 	= $myACL->can('user_acl_view_permissions');
	$canViewRoles 			= $myACL->can('user_acl_view_roles');
	$canViewUsers 			= $myACL->can('user_acl_manage_users');
	$canViewPermissions 	= $myACL->can('user_acl_view_permissions');
	$canManageRoles 		= $myACL->can('user_acl_manage_roles');
	$canManagePermissions 	= $myACL->can('user_acl_manage_permissions');
	$activeTab = '';

	if ($canViewRoles) {
		$activeTab = 'roles';
	} elseif ($canViewPermissions) {
		$activeTab = 'permissions';
	} elseif ($canViewUsers) {
		$activeTab = 'users';
	}
		
	/** Output **/
	$aAclOverview = [
		'sPermissionsList'	=> $sPermissionsList,
		'sRolesList'		=> $sRolesList,
		'sUsers'			=> $sUsers,
		'aLang' 			=> $aLang,
		'aRoles'     		=> $aRoles,
		'canView'       		=> $canView,
		'canViewPermissions' 	=> $canViewPermissions,
		'canViewRoles' 			=> $canViewRoles,
		'canViewUsers' 			=> $canViewUsers,
		'canManageRoles' 		=> $canManageRoles,
		'canManagePermissions'	=> $canManagePermissions,
		'activeTab'            	=> $activeTab,
	];

	$sOut = renderTwig(
		$oTwig,
		$sAddonThemePath,
		'acl_overview.twig',
		$aAclOverview,
		$aTplDefaults['ACL_OVERVIEW'] ?? ''
	);

	$sMain = $sOut;

} else {
	$sMain = $aLang['USER_ACL_NO_PERMISSION_FOR_MODULE'];
} 
