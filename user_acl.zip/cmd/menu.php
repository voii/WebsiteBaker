<?php


use bin\{WbAdaptor,SecureTokens,Sanitize};
use bin\helpers\{PreCheck,msgQueue};
use vendor\phplib\Template;
use addon\user_acl\AclOwners;


/* -------------------------------------------------------- */
// Must include code to stop this file being accessed directly
if (!\defined('SYSTEM_RUN')) {\header($_SERVER['SERVER_PROTOCOL'].' 404 Not Found'); echo '404 Not Found'; \flush(); exit;}
/* -------------------------------------------------------- */

    $msg = [];
    if (!$oApp->get_permission($sAddonName,'module' ) ) {
        $oApp->print_error($oTrans->MESSAGE_ADMIN_INSUFFICIENT_PRIVELLIGES, $js_back);
        exit();
    }
	
	$aclOwners = new \addon\user_acl\AclOwners();
	$isOwner = $aclOwners->isOwner($admin->getUserId() ?? ($_SESSION['USER_ID'] ?? 0));

	// Menu	
	$aNavigation = Array
	(
		Array
		(
			'id' => 1,
			'url' => WB_URL.'/admin/admintools/tool.php?tool=user_acl',
			'title' => $aLang['USER_ACL_HOME'],
			'access' => '',
			'class' => 'primary',
		),
		Array
		(
			'id' => 2,
			'url' => WB_URL.'/admin/admintools/tool.php?tool=user_acl&action=log',
			'title' => $aLang['USER_ACL_LOG'],
			'access' => '',
			'class' => 'warning',
			'log' => $myACL->getErrorCount(),
		),
		Array
		(
			'id' => 2,
			'url' => WB_URL.'/admin/admintools/tool.php?tool=user_acl&action=settings',
			'title' => $aLang['USER_ACL_SETTINGS'],
			'access' => $isOwner,
			'class' => 'info',
		)			
	);	
