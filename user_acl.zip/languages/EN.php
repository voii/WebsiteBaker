<?php

$USER_ACL['MODULE_TITLE'] 					= 'ACL';
$USER_ACL['MODULE_SUBTITLE'] 				= 'Manage Roles and Permissions across different modules';

$USER_ACL['NO_PERMISSION_FOR_MODULE'] 		= 'You have no permission to access this modules';

//Menu
$USER_ACL['HOME'] 							= 'Home';
$USER_ACL['LOG'] 							= 'Log';


$USER_ACL['ADD_NEW'] 						= 'Add new';
$USER_ACL['EDIT'] 							= 'Edit';
$USER_ACL['DELETE'] 						= 'Delete';
$USER_ACL['DELETED'] 						= 'Deleted';
$USER_ACL['RELOAD'] 						= 'Reload';
$USER_ACL['SAVE'] 							= 'Save';
$USER_ACL['UPDATE'] 						= 'Update';
$USER_ACL['CANCEL'] 						= 'Cancel';
$USER_ACL['DONE'] 							= 'Done';
$USER_ACL['THERE_IS_ERROR'] 				= 'There is error';
$USER_ACL['SEARCH']							= 'Search';
$USER_ACL['LIST'] 							= 'List';
$USER_ACL['OVERVIEW'] 						= 'Overview';
$USER_ACL['FOUND'] 							= 'Found';
$USER_ACL['DETAILS'] 						= 'Details';
$USER_ACL['SYSTEM'] 						= 'System';
$USER_ACL['CREATED_BY'] 					= 'Created by';
$USER_ACL['ENABLED'] 						= 'Enabled';
$USER_ACL['ASSIGNED'] 						= 'Assigned';
$USER_ACL['DESCRIPTION'] 					= 'Description';
$USER_ACL['COPY'] 							= 'Copy';
$USER_ACL['MANAGE'] 						= 'Manage';
$USER_ACL['SETTINGS'] 						= 'Settings';
$USER_ACL['USERS'] 							= 'Users';
$USER_ACL['GROUPS'] 						= 'Groups';
$USER_ACL['OWNER'] 							= 'Owner';


$USER_ACL['SEARCH_RESULTS']					= 'Search results';
$USER_ACL['RESULTS_FOUND']					= '%s results found';
$USER_ACL['NO_CHANGES'] 					= 'No changes';
$USER_ACL['CONFIRM_DELETE'] 				= 'Confirm delete';
$USER_ACL['YOU_WILL_DELETE_PERMISSION'] 	= 'You will delete permission';
$USER_ACL['PERMISSION_DELETED']				= 'Permission <u>%s</u> is deleted';

$USER_ACL['USERS'] 							= 'Users';
$USER_ACL['USER'] 							= 'User';
$USER_ACL['NO_USERS_FOUND'] 				= 'No Users found';
$USER_ACL['USERS_ADD_ROLE']					= 'Add role to user';
$USER_ACL['USERS_MANAGING_FOR']				= 'Managing role and permissions for <u>%s</u>';
$USER_ACL['USERS_USER_ID_INVALID']			= 'User id not set';
$USER_ACL['USERS_ADMIN_ROLE_SET']			= 'Admin role (all rolles) set for user <u>%s</u>';
$USER_ACL['USERS_ROLES_AND_PERM_SET']		= 'Updated %s role(s) and %s permission(s) for user <u>%s</u>';

$USER_ACL['ROLES'] 							= 'Roles';
$USER_ACL['ROLE'] 							= 'Role';
$USER_ACL['NO_ROLES_FOUND'] 				= 'No Roles found';
$USER_ACL['COMPARE'] 						= 'Compare';

$USER_ACL['ALLOW_ALL'] 						= 'Allow all';
$USER_ACL['DENY_ALL'] 						= 'Deny all';
$USER_ACL['IGNORE_ALL'] 					= 'Ignore all';
$USER_ACL['ALLOW'] 							= 'Allow';
$USER_ACL['DENY'] 							= 'Deny';
$USER_ACL['IGNORE'] 						= 'Ignore (not set)';
$USER_ACL['ALLOWED'] 						= 'Allowed';
$USER_ACL['DENIED'] 						= 'Denied';
$USER_ACL['IGNORED'] 						= 'Not set';
$USER_ACL['INHERIT'] 						= 'Inherit';
$USER_ACL['INHERITED'] 						= 'Inherited';
$USER_ACL['INHERITED_VIA_ROLE'] 			= 'Inherited via role';
$USER_ACL['PERMISSIONS_OVERRIDE_INFO'] 		= 'Set explicit permissions regardless of roles';
$USER_ACL['PROTECTED'] 						= 'Protected';


$USER_ACL['MANAGING_FOR']					= 'Managing roles and permissions for <u>%s</u>';
$USER_ACL['ROLE_TITLE']						= 'Title';
$USER_ACL['ROLE_TITLE_EMPTY']				= 'Role Title is empty';
$USER_ACL['ROLE_ADDED']						= 'Role <u>%s</u> added';
$USER_ACL['ROLE_UPDATED']					= 'Role <u>%s</u> updated';
$USER_ACL['YOU_WILL_DELETE_ROLE'] 			= 'You will delete role';
$USER_ACL['ROLE_DELETED']					= 'Role <u>%s</u> is deleted';
$USER_ACL['TOAST_ROLE_ASSIGNED_USERS'] 		= 'in <u>%s</u> user(s)';
$USER_ACL['TOAST_ROLE_HAS_PERMISSIONS'] 	= 'used <u>%s</u> permission(s)';
$USER_ACL['TOAST_ROLE_SYSTEM_PROTECTED'] 	= 'You cannot delete this role';


$USER_ACL['PERMISSIONS'] 					= 'Permissions';
$USER_ACL['PERMISSION'] 					= 'Permission';
$USER_ACL['NO_PERMISSIONS_FOUND'] 			= 'No Permissions found';
$USER_ACL['PERMISSION_NAME'] 				= 'Permission Name';
$USER_ACL['PERMISSION_KEY'] 				= 'Permission Key';
$USER_ACL['OTHER'] 							= 'Other';



$USER_ACL['TOAST_WAITTING_TOAST_ACTION'] 	= 'Waitting for toast action';
$USER_ACL['TOAST_PERMISSIONS_IN_ROLES'] 	= 'used in <u>%s</u> role(s)';
$USER_ACL['TOAST_PERMISSIONS_VIA_ROLES'] 	= '<u>%s</u> user(s) via roles';
$USER_ACL['TOAST_PERMISSIONS_OVERRIDES'] 	= '<u>%s</u> direct override(s)';
$USER_ACL['TOAST_ALREADY_EXISTS'] 			= 'Not possible to update because name or key already exists';
					
$USER_ACL['IS_EMPTY'] 						= 'is empty';
$USER_ACL['PERMISSION_ADDED']				= 'Permission <u>%s</u> added';
$USER_ACL['PERMISSION_UPDATED']				= 'Permission <u>%s</u> updated';
$USER_ACL['PERMISSION_HINT']				= 'If permission key starts with module directory name, it will group these permissions in list';

$USER_ACL['OVERRIDES'] 						= 'override(s)';
$USER_ACL['IN'] 							= 'in';

// Toasts
$USER_ACL['MODULE_INFO']					= 'Module Info';
$USER_ACL['COPIED_TO_CLIPBOARD']			= 'Copied to clipboard';


// Error log
$USER_ACL['ERROR_LOG_EMPTY']		 		= 'Error log empty';
$USER_ACL['ERROR_CLEAR']		 			= 'Clear Error log';
$USER_ACL['ERROR_LOG_CLEARED']		 		= 'Error log cleared';
$USER_ACL['NO_PERMISSION_FOR_ACTION'] 		= 'You have no permission for this action <u>%s</u>';


// Error 
$USER_ACL['UNKNOWN_ACTION'] 				= 'Unknown action <u>%s</u>';
$USER_ACL['OWNER_REMOVE_SELF'] 				= 'You cannot remove yourself. You must remain ACL module owner';
$USER_ACL['OWNER_REMOVE_GROUP'] 			= 'You cannot remove your last owner group access';