<?php

$USER_ACL['MODULE_TITLE']                    = 'ACL';
$USER_ACL['MODULE_SUBTITLE']                 = 'Rollen und Berechtigungen für verschiedene Module verwalten';

$USER_ACL['NO_PERMISSION_FOR_MODULE']        = 'Sie haben keine Berechtigung, auf dieses Modul zuzugreifen';

// Menü
$USER_ACL['HOME']                            = 'Startseite';
$USER_ACL['LOG']                             = 'Protokoll';

$USER_ACL['ADD_NEW']                         = 'Neu hinzufügen';
$USER_ACL['EDIT']                            = 'Bearbeiten';
$USER_ACL['DELETE']                          = 'Löschen';
$USER_ACL['DELETED']                         = 'Gelöscht';
$USER_ACL['RELOAD']                          = 'Neu laden';
$USER_ACL['SAVE']                            = 'Speichern';
$USER_ACL['UPDATE']                          = 'Aktualisieren';
$USER_ACL['CANCEL']                          = 'Abbrechen';
$USER_ACL['DONE']                            = 'Fertig';
$USER_ACL['THERE_IS_ERROR']                  = 'Es ist ein Fehler aufgetreten';
$USER_ACL['SEARCH']                          = 'Suchen';
$USER_ACL['LIST']                            = 'Liste';
$USER_ACL['OVERVIEW']                        = 'Übersicht';
$USER_ACL['FOUND']                           = 'Gefunden';
$USER_ACL['DETAILS']                         = 'Details';
$USER_ACL['SYSTEM']                          = 'System';
$USER_ACL['CREATED_BY']                      = 'Erstellt von';
$USER_ACL['ENABLED']                         = 'Aktiviert';
$USER_ACL['ASSIGNED']                        = 'Zugewiesen';
$USER_ACL['DESCRIPTION']                     = 'Beschreibung';
$USER_ACL['COPY']                            = 'Kopieren';
$USER_ACL['MANAGE']                          = 'Verwalten';
$USER_ACL['SETTINGS']                        = 'Einstellungen';
$USER_ACL['USERS']                           = 'Benutzer';
$USER_ACL['GROUPS']                          = 'Gruppen';
$USER_ACL['OWNER']                           = 'Eigentümer';

$USER_ACL['SEARCH_RESULTS']                  = 'Suchergebnisse';
$USER_ACL['RESULTS_FOUND']                   = '%s Ergebnisse gefunden';
$USER_ACL['NO_CHANGES']                      = 'Keine Änderungen';
$USER_ACL['CONFIRM_DELETE']                  = 'Löschen bestätigen';
$USER_ACL['YOU_WILL_DELETE_PERMISSION']      = 'Sie werden die Berechtigung löschen';
$USER_ACL['PERMISSION_DELETED']              = 'Berechtigung <u>%s</u> wurde gelöscht';

$USER_ACL['USERS']                           = 'Benutzer';
$USER_ACL['USER']                            = 'Benutzer';
$USER_ACL['NO_USERS_FOUND']                  = 'Keine Benutzer gefunden';
$USER_ACL['USERS_ADD_ROLE']                  = 'Rolle zum Benutzer hinzufügen';
$USER_ACL['USERS_MANAGING_FOR']              = 'Rollen und Berechtigungen für <u>%s</u> verwalten';
$USER_ACL['USERS_USER_ID_INVALID']           = 'Benutzer-ID ist nicht gesetzt';
$USER_ACL['USERS_ADMIN_ROLE_SET']            = 'Administratorrolle (alle Rollen) für Benutzer <u>%s</u> gesetzt';
$USER_ACL['USERS_ROLES_AND_PERM_SET']        = '%s Rolle(n) und %s Berechtigung(en) für Benutzer <u>%s</u> aktualisiert';

$USER_ACL['ROLES']                           = 'Rollen';
$USER_ACL['ROLE']                            = 'Rolle';
$USER_ACL['NO_ROLES_FOUND']                  = 'Keine Rollen gefunden';
$USER_ACL['COMPARE']                         = 'Vergleichen';

$USER_ACL['ALLOW_ALL']                       = 'Alle erlauben';
$USER_ACL['DENY_ALL']                        = 'Alle verweigern';
$USER_ACL['IGNORE_ALL']                      = 'Alle ignorieren';
$USER_ACL['ALLOW']                           = 'Erlauben';
$USER_ACL['DENY']                            = 'Verweigern';
$USER_ACL['IGNORE']                          = 'Ignorieren (nicht gesetzt)';
$USER_ACL['ALLOWED']                         = 'Erlaubt';
$USER_ACL['DENIED']                          = 'Verweigert';
$USER_ACL['IGNORED']                         = 'Nicht gesetzt';
$USER_ACL['INHERIT']                         = 'Vererben';
$USER_ACL['INHERITED']                       = 'Geerbt';
$USER_ACL['INHERITED_VIA_ROLE']              = 'Über Rolle geerbt';
$USER_ACL['PERMISSIONS_OVERRIDE_INFO']       = 'Explizite Berechtigungen unabhängig von Rollen festlegen';
$USER_ACL['PROTECTED']                       = 'Geschützt';

$USER_ACL['MANAGING_FOR']                    = 'Rollen und Berechtigungen für <u>%s</u> verwalten';
$USER_ACL['ROLE_TITLE']                      = 'Titel';
$USER_ACL['ROLE_TITLE_EMPTY']                = 'Rollentitel ist leer';
$USER_ACL['ROLE_ADDED']                      = 'Rolle <u>%s</u> hinzugefügt';
$USER_ACL['ROLE_UPDATED']                    = 'Rolle <u>%s</u> aktualisiert';
$USER_ACL['YOU_WILL_DELETE_ROLE']            = 'Sie werden die Rolle löschen';
$USER_ACL['ROLE_DELETED']                    = 'Rolle <u>%s</u> wurde gelöscht';
$USER_ACL['TOAST_ROLE_ASSIGNED_USERS']       = 'bei <u>%s</u> Benutzer(n)';
$USER_ACL['TOAST_ROLE_HAS_PERMISSIONS']      = 'verwendet <u>%s</u> Berechtigung(en)';
$USER_ACL['TOAST_ROLE_SYSTEM_PROTECTED']     = 'Diese Rolle kann nicht gelöscht werden';

$USER_ACL['PERMISSIONS']                     = 'Berechtigungen';
$USER_ACL['PERMISSION']                      = 'Berechtigung';
$USER_ACL['NO_PERMISSIONS_FOUND']            = 'Keine Berechtigungen gefunden';
$USER_ACL['PERMISSION_NAME']                 = 'Berechtigungsname';
$USER_ACL['PERMISSION_KEY']                  = 'Berechtigungsschlüssel';
$USER_ACL['OTHER']                           = 'Sonstiges';

$USER_ACL['TOAST_WAITTING_TOAST_ACTION']     = 'Warten auf Benachrichtigungsaktion';
$USER_ACL['TOAST_PERMISSIONS_IN_ROLES']      = 'verwendet in <u>%s</u> Rolle(n)';
$USER_ACL['TOAST_PERMISSIONS_VIA_ROLES']     = '<u>%s</u> Benutzer über Rollen';
$USER_ACL['TOAST_PERMISSIONS_OVERRIDES']     = '<u>%s</u> direkte Überschreibung(en)';
$USER_ACL['TOAST_ALREADY_EXISTS']            = 'Aktualisierung nicht möglich, da Name oder Schlüssel bereits existiert';

$USER_ACL['IS_EMPTY']                        = 'ist leer';
$USER_ACL['PERMISSION_ADDED']                = 'Berechtigung <u>%s</u> hinzugefügt';
$USER_ACL['PERMISSION_UPDATED']              = 'Berechtigung <u>%s</u> aktualisiert';
$USER_ACL['PERMISSION_HINT']                 = 'Beginnt der Berechtigungsschlüssel mit dem Modulverzeichnisnamen, werden diese Berechtigungen in der Liste gruppiert';

$USER_ACL['OVERRIDES']                       = 'Überschreibung(en)';
$USER_ACL['IN']                              = 'in';

// Benachrichtigungen
$USER_ACL['MODULE_INFO']                     = 'Modulinformationen';
$USER_ACL['COPIED_TO_CLIPBOARD']             = 'In die Zwischenablage kopiert';

// Fehlerprotokoll
$USER_ACL['ERROR_LOG_EMPTY']                 = 'Fehlerprotokoll ist leer';
$USER_ACL['ERROR_CLEAR']                     = 'Fehlerprotokoll löschen';
$USER_ACL['ERROR_LOG_CLEARED']               = 'Fehlerprotokoll gelöscht';
$USER_ACL['NO_PERMISSION_FOR_ACTION']        = 'Sie haben keine Berechtigung für diese Aktion <u>%s</u>';

// Fehler
$USER_ACL['UNKNOWN_ACTION']                  = 'Unbekannte Aktion <u>%s</u>';
$USER_ACL['OWNER_REMOVE_SELF']               = 'Sie können sich nicht selbst entfernen. Sie müssen Eigentümer des ACL-Moduls bleiben';
$USER_ACL['OWNER_REMOVE_GROUP']              = 'Sie können den Zugriff Ihrer letzten Eigentümergruppe nicht entfernen';