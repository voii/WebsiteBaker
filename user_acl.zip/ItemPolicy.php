<?php

/**
 * ACL Policies Documentation
 *
 * @category     Addons
 * @package      admin tool: user_acl
 * @author       C081
 * @license      http://www.gnu.org/licenses/gpl.html   GPL License
 * @version      1.0.0
 * @since        2026-05-01
 *
 * =========================================================
 * OVERVIEW
 * =========================================================
 * Policy classes define business rules for actions on entities
 * (e.g. Item, Category) using the ACL permission system.
 *
 * ACL handles:
 *   - permissions (can('item_edit'))
 *   - roles (admin, editor, etc.)
 *
 * Policy handles:
 *   - ownership (user_id === user->id)
 *   - entity state (locked, deleted, public...)
 *
 * =========================================================
 * USAGE EXAMPLE
 * =========================================================
 *
 * User: (user object or you directly change $user to $user_id, but further code needs modification)
 * $user = (object) [
 *     'id' => $admin->getUserId(),
 *     '...' => ...,
 * ];
 * ---------------------------------------------------------
 * ITEM EXAMPLE
 * ---------------------------------------------------------
 *
 * $acl = new \addon\user_acl\Acl($user->id); // $user->id or if no argument Acl will use $_SESSION['USER_ID'] - see Acl class
 * $policy = new \addon\user_acl\Policies\ItemPolicy($acl); // For each policy you must make sepparate class 
 *
 * Your item:
 * $item = (object) [
 *     'id' => 10,
 *     'title' => 'First item',
 *     'user_id' => 2,
 *     'status' => 'active',
 *     'is_deleted' => false,
 *     '...' => ...,
 * ];
 *
 * Current example from ItemPolicy class, you must edit to match your code and needs:
 * public function canEdit(object $user, object $item): bool
 * {
 * 		return $this->acl->can('item_edit')
 *		&& $this->isNotLocked($item)
 *		&& $this->isOwnerOrAdmin($user, $category);
 * } 
 * Later you may need to add more conditions like && $this->canDoSomethingMore(...)
 *
 * 
 * In code usage:
 * if ($policy->canEdit($user, $item)) {
 *     // allowed: user has permission AND passes policy rules
 * } else {
 *     // denied: either permission or policy rules failed
 * }
 *
 * ---------------------------------------------------------
 * CATEGORY EXAMPLE
 * ---------------------------------------------------------
 *
 * $category = (object) [
 *     'id' => 3,
 *     'name' => 'News',
 *     'user_id' => 2,
 *     'status' => 'active',
 *     'is_public' => true,
 * ];
 *
 * Same as example above, see $policy->canView below
 *
 * $policy = new \addon\user_acl\Policies\CategoryPolicy($acl);
 *
 * if ($policy->canView($user, $category)) {
 *     // allowed: user can view category
 * } else {
 *     // denied: no permission or policy restriction
 * }
 *
 * =========================================================
 * HOW TO CREATE NEW POLICY
 * =========================================================
 *
 * 1. Create new class (e.g. PostPolicy, OrderPolicy)
 * 2. Inject Acl via constructor
 * 3. Define methods:
 *      - canView()
 *      - canCreate()
 *      - canEdit()
 *      - canDelete()
 *      - others...
 * 4. Use helper methods for reusable logic
 *
 * =========================================================
 * BEST PRACTICES
 * =========================================================
 *
 * Keep ACL and Policy separate (no extends Acl)
 * Use $acl->can('permission_key')
 * Use role names instead of IDs (readability)
 * Extract reusable logic into helper methods
 * Keep methods small and readable
 * separate Policies in files: ItemPolicy.php , CategoryPolicy.php
 *
 */

// Example CategoryPolicy

namespace addon\user_acl\Policies;
use addon\user_acl\Acl;

class CategoryPolicy
{
    protected Acl $acl;

    public function __construct(Acl $acl)
    {
        $this->acl = $acl;
    }

    /**
     * VIEW CATEGORY
     */
    public function canView(object $user, object $category): bool
    {
        return $this->acl->can('categories_view')
            && (
                $this->isPublic($category)
                || $this->isOwnerOrAdmin($user, $category)
            );
    }

    /**
     * CREATE CATEGORY
     */
    public function canCreate(object $user): bool
    {
        return $this->acl->can('categories_create');
    }

    /**
     * EDIT CATEGORY
     */
    public function canEdit(object $user, object $category): bool
    {
        return $this->acl->can('categories_edit')
            && $this->isNotLocked($category)
            && $this->isOwnerOrAdmin($user, $category);
    }

    /**
     * DELETE CATEGORY
     */
    public function canDelete(object $user, object $category): bool
    {
        return $this->acl->can('categories_delete')
            && $this->isOwnerOrAdmin($user, $category);
    }

    /* ================= HELPERS ================= */

    protected function isOwnerOrAdmin(object $user, object $category): bool
    {
        return ($category->user_id === $user->id)
            || $this->acl->userHasRoleName('admin');
    }

    protected function isPublic(object $category): bool
    {
        return !empty($category->is_public);
    }

    protected function isNotLocked(object $category): bool
    {
        return ($category->status ?? null) !== 'locked';
    }
}

// Example ItemPolicy:

// namespace addon\user_acl\Policies;
// use addon\user_acl\Acl;

class ItemPolicy
{
    protected Acl $acl;

    public function __construct(Acl $acl)
    {
        $this->acl = $acl;
    }

    /**
     * EDIT ITEM
     */
    public function canEdit(object $user, object $item): bool
    {
        return $this->acl->can('item_edit')
            && $this->isNotLocked($item)
            && $this->isOwnerOrAdmin($user, $item);
    }

    /**
     * DELETE ITEM
     */
    public function canDelete(object $user, object $item): bool
    {
        return $this->acl->can('item_delete')
            && $this->isOwnerOrAdmin($user, $item);
    }

    /**
     * VIEW ITEM
     */
    public function canView(object $user, object $item): bool
    {
        return $this->acl->can('item_view')
            && !$this->isDeleted($item);
    }

    /**
     * CREATE ITEM
     */
    public function canCreate(object $user): bool
    {
        return $this->acl->can('item_create');
    }

    /* ================= HELPERS ================= */

    protected function isOwnerOrAdmin(object $user, object $item): bool
    {
        return ($item->user_id === $user->id)
            || $this->acl->userHasRoleName('admin');
    }

    protected function isNotLocked(object $item): bool
    {
        return ($item->status ?? null) !== 'locked';
    }

    protected function isDeleted(object $item): bool
    {
        return !empty($item->is_deleted);
    }
}

