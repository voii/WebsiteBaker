<?php

/**
 * @category     Addons
 * @package      admin tool: user_acl
 * @copyright    C081
 * @author       C081
 * @license      http://www.gnu.org/licenses/gpl.html   GPL License
 * @version      1.0.0
 * @lastmodified $Date: 2026/01/01
 * @since        File available since 2026/01/01
 * @description  addon user_acl
*/

namespace addon\user_acl;

use bin\{WbAdaptor};

class Acl
{
    /** @var object Database instance */
    protected $oDb;

    /** @var object Registry / global app container */
    protected $oReg;

    /** @var array Translate / global app container */
    protected $aLang;

    /** @var array Final permissions (merged role + user perms) */
    public array $aPerms = [];

    /** @var array User roles */
    public array $userRoles = [];

    /** @var int|null Current user ID */
    public ?int $iUserId = null;

    /** @var array Cache */
    protected array $permMap = [];
	protected array $roleMap = [];
	
    public function __construct($iUserId = null)
    {
        $this->oReg 	= WbAdaptor::getInstance();
        $this->oDb  	= $this->oReg->getDatabase();
        $this->aLang  	= $this->oReg->getTranslate()->getLangArray();
        $this->iUserId 	= $iUserId ?? ($_SESSION['USER_ID'] ?? 0);
        $this->permMap 	= $this->getPermMap();
		$this->roleMap 	= $this->getRoleMap();		
        $this->userRoles 	= $this->getUserRoles();
        $this->buildACL();
    }

    /* ====================== CACHE ======================== */
    private function getPermMap(): array
    {
        $aOut = [];

        $sSql = 'SELECT id, perm_key, perm_name 
                 FROM `'.$this->oDb->sTablePrefix.'mod_user_acl_permissions` ORDER BY perm_key ASC';

        if ($oRes = $this->oDb->query($sSql)) {
            while ($row = $oRes->fetchRow(MYSQLI_ASSOC)) {
                $aOut[$row['id']] = [
                    'key'  => strtolower($row['perm_key']),
                    'name' => $row['perm_name']
                ];
            }
        }

        return $aOut;
    }

	private function getRoleMap(): array
	{
		$aOut = [];

		$sSql = 'SELECT id, role_name, role_description
				 FROM `'.$this->oDb->sTablePrefix.'mod_user_acl_roles`';

		if ($oRes = $this->oDb->query($sSql)) {
			while ($row = $oRes->fetchRow(MYSQLI_ASSOC)) {
				$aOut[(int)$row['id']] = [
					'name'        => $row['role_name'],
					'description' => $row['role_description']
				];
			}
		}

		return $aOut;
	}

    /* ================= USER ROLES ========================= */
    public function getUserRoles(): array
    {
        $aOut = [];

        $sSql = 'SELECT role_id 
                 FROM `'.$this->oDb->sTablePrefix.'mod_user_acl_user_roles` 
                 WHERE user_id = '.(int)$this->iUserId;

        if ($oRes = $this->oDb->query($sSql)) {
            while ($row = $oRes->fetchRow(MYSQLI_ASSOC)) {
                $aOut[] = (int)$row['role_id'];
            }
        }
        return $aOut;
    }

    /* ================= BUILD ACL ========================== */

    /**
     * Combine role + user permissions
     */
    private function buildACL(): array
    {
        // 1. Role perms
        if (!empty($this->userRoles)) {
            $rolePerms = $this->getRolePerms($this->userRoles);
            $this->aPerms = array_merge($this->aPerms, $rolePerms);
        }

        // 2. User perms (override)
        $userPerms = $this->getUserPerms($this->iUserId);
        $this->aPerms = array_merge($this->aPerms, $userPerms);

        return $this->aPerms;
    }

    /* ================= ROLE PERMISSIONS =================== */
    public function getRolePerms($mRole): array
    {
        $aOut = [];

        if (empty($mRole)) {
            return $aOut;
        }

        if (is_array($mRole)) {
            $ids = implode(',', array_map('intval', $mRole));
            $sSql = "SELECT * FROM `".$this->oDb->sTablePrefix."mod_user_acl_role_perms`
                     WHERE role_id IN ($ids)
                     ORDER BY value DESC";
        } else {
            $sSql = "SELECT * FROM `".$this->oDb->sTablePrefix."mod_user_acl_role_perms`
                     WHERE role_id = ".(int)$mRole."
                     ORDER BY value DESC";
        }

        if ($oRes = $this->oDb->query($sSql)) {
            while ($aRow = $oRes->fetchRow(MYSQLI_ASSOC)) {

                $permId = (int)$aRow['perm_id'];

                if (!isset($this->permMap[$permId])) {
                    continue;
                }

                $pK = $this->permMap[$permId]['key'];
                $hP = ($aRow['value'] == '1');

                $aOut[$pK] = [
                    'perm'        => $pK,
                    'inherited'  => true,
                    'value'       => $hP,
                    'name'        => $this->permMap[$permId]['name'],
                    'id'          => $permId
                ];
            }
        }

        return $aOut;
    }

    /* ================= USER PERMISSIONS =================== */
    public function getUserPerms($iUserId): array
    {
        $aOut = [];
        $sSql = 'SELECT * FROM `'.$this->oDb->sTablePrefix.'mod_user_acl_user_perms`
                 WHERE user_id = '.(int)$iUserId;

        if ($oRes = $this->oDb->query($sSql)) {
            while ($aRow = $oRes->fetchRow(MYSQLI_ASSOC)) {
                $permId = (int)$aRow['perm_id'];
                if (!isset($this->permMap[$permId])) {
                    continue;
                }
                $pK = $this->permMap[$permId]['key'];
                $hP = ($aRow['value'] == '1'); // FIX BUG

                $aOut[$pK] = [
                    'perm'        => $pK,
                    'inherited'  => false,
                    'value'       => $hP,
                    'name'        => $this->permMap[$permId]['name'],
                    'id'          => $permId
                ];
            }
        }

        return $aOut;
    }

    /* ================= HELPERS ============================ */
	public function getPermKeyFromID($iPermId): ?string
	{
		return $this->permMap[$iPermId]['key'] ?? null;
	}

	public function getPermNameFromID($iPermId): ?string
	{
		return $this->permMap[$iPermId]['name'] ?? null;
	}
	public function getRoleNameFromID($iRoleId): ?string
	{
		return $this->roleMap[$iRoleId]['name'] ?? null;
	}	
	public function getRoleDescriptionFromID($iRoleId): ?string
	{
		return $this->roleMap[$iRoleId]['description'] ?? null;
	}	

    public function userHasRole($iRoleId): bool
    {
        return in_array((int)$iRoleId, $this->userRoles, true);
    }

	public function userHasRoleName(string|array $roleNames): bool
	{
		$roleNames = (array)$roleNames;

		foreach ($this->userRoles as $roleId) {

			$roleName = $this->roleMap[$roleId]['name'] ?? null;

			if ($roleName && in_array($roleName, $roleNames, true)) {
				return true;
			}
		}

		return false;
	}
	
	public function getAllRoles(): array
	{
		$out = [];
		foreach ($this->roleMap as $id => $role) {
			$out[] = [
				'id'          => (int)$id,
				'name'        => $role['name'],
				'description' => $role['description']
			];
		}
		return $out;
	}
	
	public function getAllPerms(): array
	{
		$out = [];
		foreach ($this->permMap as $id => $perm) {
			$out[$perm['key']] = [
				'id'   => $id,
				'name' => $perm['name'],
				'key'  => $perm['key'],
			];
		}
		return $out;
	}

    public function can(string $sKey): bool
    {
		if ($this->iUserId === 0 && empty($this->aPerms)) {
			return false;
		}
		$sKey = strtolower($sKey ?? '');
        if (!$sKey) {
            return false;
        }
        $this->ifPermissionExists($sKey);
        return !empty($this->aPerms[$sKey]['value']);
    }

	public function canAny(array $perms): bool
	{
		foreach ($perms as $p) {
			if ($this->can($p)) {
				return true;
			}
		}
		return false;
	}

	public function canAll(array $perms): bool
	{
		foreach ($perms as $p) {
			if (!$this->can($p)) {
				return false;
			}
		}
		return true;
	}

    /* ================= DEBUG ========================================== */
    /* ==== If key doesnt exist in DB using $x->hasPermission('Key') ==== */
    /* =================== will log the line for debug ================== */
	private function ifPermissionExists(string $sKey): void
	{
		$sSql = sprintf(
			"SELECT perm_key FROM `%smod_user_acl_permissions` WHERE perm_key = '%s'",
			$this->oDb->sTablePrefix,
			$this->oDb->escapeString($sKey)
		);

		if (!$this->oDb->get_one($sSql)) {

			$trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
			$caller = $trace[1] ?? $trace[0] ?? null;

			if (isset($caller['file'], $caller['line'])) {

				$sMessage = sprintf(
					"\nLINE: %s IN FILE: %s",
					$caller['line'],
					str_replace('\\', '\\\\', $caller['file'])
				);

				$sSql = sprintf(
					"INSERT INTO `%smod_user_acl_errors`
					 (perm_key, message)
					 VALUES ('%s','%s')",
					$this->oDb->sTablePrefix,
					$this->oDb->escapeString($sKey),
					$this->oDb->escapeString($sMessage)
				);

				$this->oDb->query($sSql);
			}
		}
	}
}