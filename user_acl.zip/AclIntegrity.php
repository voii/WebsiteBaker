<?php

/**
 * @category     Addons
 * @package      admin tool: user_acl
 * @copyright    C081
 * @author       C081
 * @license      http://www.gnu.org/licenses/gpl.html   GPL License
 * @version      1.0.0
 * @lastmodified $Date: 2026/01/01
 * @since        File available since 2026/01/01
 * @description  addon user_acl, protect system permissions and roles
*/

namespace addon\user_acl;

use bin\{WbAdaptor};

class AclIntegrity
{
    protected $oDb;
    public const PROTECTED_ROLE_ID = 1; // Administrator
	protected const REQUIRED_PERMISSIONS = [
		'user_acl_access',
		'user_acl_manage_users',
		'user_acl_view_roles',
		'user_acl_manage_roles',
		'user_acl_view_permissions',
		'user_acl_manage_permissions',
	];
    public const PROTECTED_PERMISSION_PREFIX = 'user_acl_';
    private const INTEGRITY_SESSION_KEY = 'user_acl_integrity_checked';
    private const INTEGRITY_TTL = 300;
    protected array $settings = [];
	
    public function __construct()
    {
        $this->oReg 	= WbAdaptor::getInstance();
        $this->oDb  	= $this->oReg->getDatabase();
        $this->loadSettings();
    }

    /**
     * Check if module permission exists, so you can manage module
     */
	public function checkModuleIntegrity(bool $cache = true): void
	{
		$sessionKey = 'user_acl_integrity_checked';
		$ttl = 600;

		if (
			$cache &&
			isset($_SESSION[$sessionKey]) &&
			$_SESSION[$sessionKey] > (time() - $ttl)
		) {
			return;
		}

		$permissions = array_map(
			[$this->oDb, 'escapeString'],
			self::REQUIRED_PERMISSIONS
		);

		$sql = sprintf(
			"SELECT perm_key
			 FROM `%smod_user_acl_permissions`
			 WHERE perm_key IN ('%s')",
			$this->oDb->sTablePrefix,
			implode("','", $permissions)
		);

		$existing = [];

		if ($res = $this->oDb->query($sql)) {
			while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
				$existing[] = $row['perm_key'];
			}
		}

		$missing = array_diff(self::REQUIRED_PERMISSIONS, $existing);

		if (!empty($missing)) {
			throw new \RuntimeException(
				sprintf(
					'ACL module integrity check failed. Missing %d permission(s): %s',
					count($missing),
					implode(', ', $missing)
				)
			);
		}

		if ($cache) {
			$_SESSION[$sessionKey] = time();
		}
	}
	public function getRequiredPermissions(): array
	{
		return self::REQUIRED_PERMISSIONS;
	}	
    /**
     * Protect administraor role from deleting
     */
	public function isProtectedRole(int $roleId): bool
	{
		return $roleId === self::PROTECTED_ROLE_ID;
	}
	
    /**
     * Protect this modules permission from deleting or editing
     */
	public function isProtectedPermission(string $permKey): bool
	{
			return str_starts_with(
			strtolower($permKey),
			self::PROTECTED_PERMISSION_PREFIX
		);
	}
	public function isRequiredPermission(string $permKey): bool
	{
		return in_array(strtolower($permKey), self::REQUIRED_PERMISSIONS, true);
	}	
    /**
     * Who is module owner, set user who installed module module owner, and his groups (
     */
	public function isOwner(int $iUserId): bool
	{
		$aOwnerUsers = array_filter(
			array_map('intval', explode(',', $this->settings['owner_user_ids'] ?? ''))
		);

		if (in_array($iUserId, $aOwnerUsers, true)) {
			return true;
		}

		$sGroups = $this->oDb->get_one(sprintf(
			"SELECT groups_id
			 FROM `%susers`
			 WHERE user_id=%d",
			$this->oDb->sTablePrefix,
			$iUserId
		));

		if (!$sGroups) {
			return false;
		}

		$aUserGroups = array_map('intval', explode(',', $sGroups));

		$aOwnerGroups = array_filter(
			array_map('intval', explode(',', $this->settings['owner_group_ids'] ?? ''))
		);

		return !empty(array_intersect($aUserGroups, $aOwnerGroups));
	}

	public function isPermissionEditable(string $permKey, int $iUserId): bool
	{
		// 1. REQUIRED = never change
		if (in_array($permKey, self::REQUIRED_PERMISSIONS, true)) {
			return false;
		}

		// user_acl_* can change only owner
		if ($this->isProtectedPermission($permKey)) {
			return $this->isOwner($iUserId);
		}

		// Other permissions can change user who has 
		// user_acl_manage_permissions (check this outside this method)
		return true;
	}

	protected function loadSettings(): void
	{
		$sql = sprintf(
			"SELECT setting_key, setting_value
			 FROM `%smod_user_acl_settings`",
			$this->oDb->sTablePrefix
		);

		if ($res = $this->oDb->query($sql)) {
			while ($row = $res->fetchRow(MYSQLI_ASSOC)) {
				$this->settings[$row['setting_key']] = $row['setting_value'];
			}
		}
	}	
}