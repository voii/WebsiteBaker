<?php

$module_directory = 'user_acl';
$module_name = 'ACL';
$module_function = 'tool';
$module_version = '0.2.0';
$module_platform = '2.13.x';
$module_author = 'Crnogorac081';
$module_license = 'GPL';
$module_description = 'ACL';

?>

